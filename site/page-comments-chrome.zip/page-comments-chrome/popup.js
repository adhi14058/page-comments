// ../core/core.js
var TRACKING = /^(utm_\w+|fbclid|gclid|gclsrc|dclid|gbraid|wbraid|gad_source|gad_campaignid|msclkid|yclid|ysclid|twclid|ttclid|li_fat_id|epik|sccid|igshid|igsh|srsltid|mc_cid|mc_eid|mkt_tok|_hsenc|_hsmi|__hssc|__hstc|__hsfp|hsctatracking|oly_anon_id|oly_enc_id|vero_id|vero_conv|wickedid|rb_clickid|s_cid|_openstat|_gl|__s|ml_subscriber|ml_subscriber_hash|ss_email_id|bsft_uid|bsft_clkid|guce_referrer|guce_referrer_sig)$/i;
var pageKey = (href) => {
  const url2 = String(href).split("#")[0], q = url2.indexOf("?");
  if (q < 0) return url2;
  const kept = url2.slice(q + 1).split("&").filter((p) => !TRACKING.test(p.split("=")[0]));
  return url2.slice(0, q) + (kept.length ? "?" + kept.join("&") : "");
};

// popup.js
var api = globalThis.browser ?? chrome;
var $ = (id) => document.getElementById(id);
var el = (tag, props, ...kids) => {
  const e = Object.assign(document.createElement(tag), props);
  e.append(...kids);
  return e;
};
var say = (text) => Object.assign($("why"), { textContent: text, hidden: false });
var [tab] = await api.tabs.query({ active: true, currentWindow: true });
var url = tab?.url || "";
var web = /^https?:/.test(url);
var origin = web ? new URL(url).origin : null;
var site = web ? `${new URL(url).protocol}//${new URL(url).hostname}/*` : null;
$("version").textContent = "v" + api.runtime.getManifest().version;
var command = (await api.commands.getAll()).find((c) => c.name === "start");
$("key").textContent = command?.shortcut || "";
$("key").title = "Starts or closes the tool on this page";
$("key").hidden = !command?.shortcut;
if (!web) say("page-comments works on web pages (addresses starting with http or https).");
else {
  api.runtime.connect({ name: "popup:" + tab.id });
  api.runtime.sendMessage({ type: "open", tabId: tab.id }).then((r) => r?.error ? Promise.reject(new Error(r.error)) : $("here").hidden = false).catch((err) => say("Could not start here: " + err.message));
}
$("close").onclick = () => api.runtime.sendMessage({ type: "close", tabId: tab.id }).then(() => close(), () => close());
var { declined = {} } = await api.storage.local.get("declined");
$("keep").hidden = !web || declined[origin] || await api.permissions.contains({ origins: [site] });
$("allow").onclick = () => {
  api.permissions.request({ origins: [site] }).then((ok) => {
    if (ok) $("keep").hidden = true;
  }, () => {
  });
};
$("later").onclick = async () => {
  declined[origin] = true;
  await api.storage.local.set({ declined });
  $("keep").hidden = true;
};
var ago = (t) => {
  const d = Math.round((Date.now() - t) / 864e5);
  return d < 1 ? "today" : d === 1 ? "yesterday" : d < 7 ? `${d} days ago` : d < 14 ? "last week" : `${Math.round(d / 7)} weeks ago`;
};
var { index = {} } = await api.storage.local.get("index");
var here = pageKey(url);
var draw = (filter = "") => {
  const f = filter.trim().toLowerCase();
  const pages = Object.entries(index).filter(([page, p]) => !f || page.toLowerCase().includes(f) || p.title.toLowerCase().includes(f));
  const bySite = /* @__PURE__ */ new Map();
  for (const [page, p] of pages.sort((a, b) => b[1].at - a[1].at)) {
    const host = new URL(page).host;
    if (!bySite.has(host)) bySite.set(host, []);
    bySite.get(host).push([page, p]);
  }
  $("list").replaceChildren(...bySite.size ? [...bySite].flatMap(([host, list]) => [
    el("div", { className: "site" }, el("span", { textContent: host }), el("span", { textContent: `${list.length} page${list.length === 1 ? "" : "s"}` })),
    ...list.map(([page, p]) => el(
      "button",
      {
        className: "pg" + (pageKey(page) === here ? " here" : ""),
        title: page,
        onclick: () => pageKey(page) === here ? close() : api.tabs.create({ url: page }).then(() => close())
      },
      el("span", {}, el("b", { textContent: p.title }), el("small", { textContent: pageKey(page) === here ? `This page \xB7 ${p.count} comment${p.count === 1 ? "" : "s"}` : `${new URL(page).pathname} \xB7 ${ago(p.at)}` })),
      el("span", { className: "cnt", textContent: p.count })
    ))
  ]) : [el("p", { className: "empty", textContent: f ? "No commented page matches." : "Pages you comment on show up here." })]);
};
$("search").oninput = (e) => draw(e.target.value);
draw();

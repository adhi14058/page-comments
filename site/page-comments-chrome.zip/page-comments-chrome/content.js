(() => {
  // ../core/core.js
  var FRAME_SEP = " >>> ";
  var shortSelector = (selector, keep = 3) => String(selector).split(FRAME_SEP).map((one) => {
    const parts = one.split(" > ");
    const tail = parts.slice(Math.max(0, parts.findLastIndex((p) => /^[\w-]*#/.test(p))));
    return tail.length <= keep + 1 ? tail.join(" > ") : `${tail[0]} > \u2026 > ${tail.slice(-keep).join(" > ")}`;
  }).join(FRAME_SEP);
  var TRACKING = /^(utm_\w+|fbclid|gclid|gclsrc|dclid|gbraid|wbraid|gad_source|gad_campaignid|msclkid|yclid|ysclid|twclid|ttclid|li_fat_id|epik|sccid|igshid|igsh|srsltid|mc_cid|mc_eid|mkt_tok|_hsenc|_hsmi|__hssc|__hstc|__hsfp|hsctatracking|oly_anon_id|oly_enc_id|vero_id|vero_conv|wickedid|rb_clickid|s_cid|_openstat|_gl|__s|ml_subscriber|ml_subscriber_hash|ss_email_id|bsft_uid|bsft_clkid|guce_referrer|guce_referrer_sig)$/i;
  var pageKey = (href) => {
    const url = String(href).split("#")[0], q = url.indexOf("?");
    if (q < 0) return url;
    const kept = url.slice(q + 1).split("&").filter((p) => !TRACKING.test(p.split("=")[0]));
    return url.slice(0, q) + (kept.length ? "?" + kept.join("&") : "");
  };
  var SHARED = ["id", "comment", "selector", "selectedText", "dx", "dy", "area", "items", "group", "text", "html", "info", "size", "background", "frozen", "by"];
  var PIC_URL = /^data:image\/(webp|png|jpeg);base64,[A-Za-z0-9+/=]+$/;
  var colour = (v) => typeof v === "string" && /^(#[0-9a-f]{3,8}|transparent)$/i.test(v);
  var box = (b) => b && ["dx", "dy", "w", "h"].every((k) => Number.isFinite(b[k])) ? { dx: b.dx, dy: b.dy, w: b.w, h: b.h } : null;
  var fromLink = (c, page) => {
    if (!c || typeof c.comment !== "string" || typeof c.selector !== "string" || typeof c.id !== "string") return null;
    const out = Object.fromEntries(SHARED.filter((k) => c[k] !== void 0).map((k) => [k, c[k]]));
    out.dx = +out.dx || 0;
    out.dy = +out.dy || 0;
    for (const k of ["text", "html", "selectedText", "size"]) if (k in out && typeof out[k] !== "string") out[k] = "";
    if (out.info && !(colour(out.info.background) && colour(out.info.color))) delete out.info;
    if (out.background !== void 0 && !colour(out.background)) delete out.background;
    if (out.area) {
      out.area = box(out.area);
      if (!out.area) return null;
    }
    if (typeof out.by === "string" && out.by.trim()) out.by = out.by.trim().slice(0, 40);
    else delete out.by;
    if (out.items !== void 0) {
      if (!Array.isArray(out.items)) return null;
      const items = out.items.map((it) => it && typeof it.selector === "string" && {
        selector: it.selector,
        text: typeof it.text === "string" ? it.text : "",
        ...it.box !== void 0 ? { box: box(it.box) } : {}
      });
      if (!items.every((it) => it && it.box !== null)) return null;
      out.items = items;
    }
    if ((out.area || out.group) && !out.items) return null;
    const pics = Array.isArray(c.pics) ? c.pics.filter((p) => p && typeof p.url === "string" && PIC_URL.test(p.url) && Number.isFinite(p.width)) : [];
    return { ...out, page, shared: true, pics, hadPic: c.hadPic === true };
  };
  var startPageComments = (platform) => {
    const SERVER = "http://localhost:4747";
    const SITE = "https://page-comments.heyadhi.com/";
    const GITHUB = "https://github.com/adhi14058/page-comments";
    const fromGithub = platform.checkVersion === "github";
    const VERSION = "1.10.8";
    if (window.__pageComments) return window.__pageComments();
    const host = document.createElement("div");
    host.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483647";
    const root = host.attachShadow({ mode: platform.shadowMode || "open" });
    const sheet = new CSSStyleSheet();
    sheet.replaceSync(`
    /* Stop the page's inherited styles (dark color-scheme, text color, fonts) from reaching our UI. */
    :host { all: initial; color-scheme: light; direction: ltr; } /* all leaves direction alone: an RTL page would mirror the bar */
    * { box-sizing: border-box; margin: 0; font: 13px/1.4 system-ui, -apple-system, 'Segoe UI', sans-serif; }
    [hidden] { display: none !important; }
    .hl { position: fixed; pointer-events: none; outline: 2px solid #2563eb; outline-offset: -1px; background: #2563eb1a; border-radius: 2px; }
    /* The info pill over the outline: tag, size, an "Aa" chip in the real text colour on the real background, and the
       background code. With details on (D, or the comment box's tab) a card adds the rest. Both flip below the element near the top of the screen. */
    .pill, .more { position: absolute; left: -2px; background: #18181b; color: #e4e4e7; box-shadow: 0 6px 18px #0004; white-space: nowrap;
                   font: 11px/1 ui-monospace, monospace; }
    .pill { bottom: calc(100% + 4px); display: flex; align-items: center; gap: 8px; padding: 4px 8px 4px 4px; border-radius: 8px; }
    .pill .t { background: #2563eb; color: #fff; padding: 3px 6px; border-radius: 5px; font-weight: 700; }
    .aa { display: inline-grid; place-items: center; width: 22px; height: 18px; border-radius: 4px; font: 700 11px system-ui, sans-serif; box-shadow: inset 0 0 0 1px #0002; }
    .pill .dim { color: #a1a1aa; }
    .pill kbd { font: 10px ui-monospace, monospace; color: #71717a; border: 1px solid #3f3f46; border-radius: 3px; padding: 1px 3px; }
    .more { bottom: calc(100% + 34px); border-radius: 8px; padding: 8px 10px; line-height: 1.7; display: none; }
    .hl.details .more { display: block; }
    .more .k { color: #a1a1aa; display: inline-block; width: 72px; }
    .hl.below .pill { bottom: auto; top: calc(100% + 4px); }
    .hl.below .more { bottom: auto; top: calc(100% + 34px); }
    .ok { color: #4ade80; } .bad { color: #f87171; }
    /* The pin's pointed bottom-left corner sits on the spot that was clicked. */
    .pin { position: fixed; pointer-events: auto; width: 24px; height: 24px; margin: -24px 0 0 0; padding: 0; cursor: pointer;
           border: 2px solid #fff; border-radius: 50% 50% 50% 0; background: #ea580c; color: #fff; font-weight: 700; font-size: 11px;
           box-shadow: 0 2px 8px #0006; }
    .pin:hover { background: #c2410c; transform: scale(1.1); }
    /* The round button sits at the widget's centre; the action buttons fan out around it on hover. */
    /* The toolbar is a pill dock: on hover the round button grows into a bar (modes | outputs | \u22EF), toward the middle of
       the screen (.left: it opens to the right). The \u22EF opens a list of the rarer actions with names and keys. */
    .widget { position: fixed; width: 0; height: 0; }
    .quick-close { position: absolute; top: -11px; left: 34px; width: 22px; height: 22px; padding: 0; border: 0; border-radius: 50%; display: grid;
                   place-items: center; background: #18181b; color: #e4e4e7; cursor: pointer; pointer-events: auto; box-shadow: 0 2px 8px #0005, 0 0 0 1px #ffffff26;
                   opacity: 0; visibility: hidden; transition: opacity .15s, visibility .15s, background .15s; }
    .quick-close svg { width: 10px; height: 10px; }
    .quick-close:hover { background: #dc2626; color: #fff; }
    .widget.left .quick-close { left: auto; right: 34px; }
    .widget.open .quick-close, .quick-close:focus-visible { opacity: 1; visibility: visible; }
    .bar { position: absolute; top: -26px; right: -26px; display: flex; align-items: center; border-radius: 30px; pointer-events: auto;
            transition: background .2s, box-shadow .2s, padding .2s; }
    .widget.left .bar { right: auto; left: -26px; flex-direction: row-reverse; }
    .items { display: flex; align-items: center; gap: 2px; max-width: 0; opacity: 0; overflow: hidden; pointer-events: none;
             transition: max-width .35s cubic-bezier(.2, .8, .2, 1), opacity .2s; }
    .widget.open .bar { background: #18181b; box-shadow: 0 10px 30px #0006, 0 0 0 1px #ffffff26; padding-left: 8px; }
    .widget.open.left .bar { padding-left: 0; padding-right: 8px; }
    .widget.open .items { max-width: 680px; opacity: 1; pointer-events: auto; animation: unclip 0s .35s forwards; }
    @keyframes unclip { to { overflow: visible; } } /* tooltips may leave the bar once it has finished growing */
    .main { position: relative; flex: none; width: 52px; height: 52px; border-radius: 50%; border: 0; padding: 0; cursor: pointer;
            display: grid; place-items: center; color: #fff; background: #ea580c; pointer-events: auto; touch-action: none;
            box-shadow: 0 8px 24px #ea580c66, 0 0 0 3px #ffffff44; transition: background .25s, transform .2s, box-shadow .2s; }
    .main:hover { transform: scale(1.06); }
    .main.on { background: #2563eb; box-shadow: 0 8px 24px #2563eb66, 0 0 0 3px #ffffff44; }
    .widget.open .main { box-shadow: none; }
    .main.dragging { cursor: grabbing; transform: scale(1.08); }
    /* The round button's own tooltip: what a click and a drag do. It hugs the screen edge the widget sits on. */
    .main .label { left: auto; right: 0; translate: none; }
    .widget.left .main .label { left: 0; right: auto; }
    .widget.top .main .label { bottom: auto; top: calc(100% + 10px); }
    .main:hover .label, .main:focus-visible .label { opacity: 1; }
    .main.dragging .label { opacity: 0; }
    .main svg { width: 24px; height: 24px; }
    .badge { position: absolute; top: -4px; right: -4px; min-width: 22px; height: 22px; padding: 0 5px; border-radius: 11px; border: 2px solid #fff;
             background: #18181b; color: #fff; font: 700 11px/18px system-ui, sans-serif; text-align: center; }
    .widget.open .badge { display: none; } /* the open bar shows the count on its Comments button */
    .dot { position: absolute; top: -2px; left: -2px; width: 14px; height: 14px; border-radius: 50%; border: 2px solid #fff; background: #16a34a; }
    .act { position: relative; flex: none; min-width: 36px; height: 36px; border-radius: 10px; border: 0; padding: 0 9px; cursor: pointer;
           display: flex; align-items: center; justify-content: center; gap: 6px; background: transparent; color: #e4e4e7; text-decoration: none;
           font: 600 12px system-ui, sans-serif; transition: background .15s; }
    .act svg { width: 16px; height: 16px; flex: none; }
    .act:hover:not(:disabled) { background: #3f3f46; color: #fff; }
    .act:disabled { color: #71717a; cursor: not-allowed; }
    .act.active { background: #2563eb; color: #fff; } .act.active:hover { background: #1d4ed8; }
    .act .ontxt { display: none; } .act.active .ontxt { display: inline; }
    .act.send { background: #ea580c; color: #fff; } .act.send:hover:not(:disabled) { background: #c2410c; }
    .act .cnt { background: #ea580c; color: #fff; border-radius: 999px; font: 700 10.5px/16px system-ui, sans-serif; padding: 0 6px; }
    .act.dots.on { background: #3f3f46; color: #fff; }
    .sep { width: 1px; height: 22px; background: #3f3f46; margin: 0 6px; flex: none; }
    /* Tooltips: above the bar, or below it near the top of the screen. */
    .label { position: absolute; left: 50%; bottom: calc(100% + 10px); translate: -50% 0; white-space: nowrap; background: #18181b; color: #fafafa;
             font: 600 11px/1 system-ui, sans-serif; padding: 6px 8px; border-radius: 6px; box-shadow: 0 4px 12px #0004, 0 0 0 1px #ffffff1f;
             opacity: 0; pointer-events: none; transition: opacity .15s; }
    .widget.top .items .label { bottom: auto; top: calc(100% + 10px); }
    .act:hover .label, .act:focus-visible .label, .act.flash .label { opacity: 1; }
    .label kbd { margin-left: 7px; font: 600 10px ui-monospace, monospace; color: #a1a1aa; border: 1px solid #3f3f46; border-radius: 3px; padding: 1px 4px; }
    .act.flash .label kbd { display: none; }
    /* The \u22EF list: white rows with icon, name and key. */
    .more-list { position: absolute; right: -26px; bottom: 38px; width: 272px; background: #fff; border-radius: 12px; padding: 6px; pointer-events: auto;
                 box-shadow: 0 12px 32px #0006, 0 0 0 1px #0000001a; display: none; }
    .widget.left .more-list { right: auto; left: -26px; }
    .widget.top .more-list { bottom: auto; top: 38px; }
    .widget.open.listopen .more-list { display: block; }
    .grp { font: 700 10px system-ui, sans-serif; letter-spacing: .06em; text-transform: uppercase; color: #a1a1aa; padding: 8px 8px 2px; }
    .more-list .act { width: 100%; height: auto; justify-content: flex-start; gap: 10px; padding: 7px 8px; border-radius: 8px; color: #18181b; font: 500 13px system-ui, sans-serif; }
    .more-list .act svg { color: #52525b; }
    .more-list .act:hover:not(:disabled) { background: #f4f4f5; color: #18181b; }
    .more-list .label { position: static; translate: none; flex: 1; display: flex; justify-content: space-between; background: none; color: inherit; font: inherit;
                        padding: 0; box-shadow: none; opacity: 1; white-space: normal; gap: 8px; text-align: left; line-height: 1.35; }
    .more-list .label kbd { flex: none; align-self: flex-start; }
    /* While commenting, the main keys sit in a small card above the round button (below it near the top), one per row,
       so people learn them. It never takes clicks, and it steps aside for anything else of ours that opens near it. */
    .keystrip { position: absolute; right: -26px; bottom: 36px; display: grid; grid-template-columns: auto auto; gap: 4px 8px; align-items: center;
                white-space: nowrap; pointer-events: none; background: #fff; color: #3f3f46; border-radius: 10px; padding: 8px 10px;
                font: 500 12px system-ui, sans-serif; box-shadow: 0 10px 30px #0005; }
    .widget.left .keystrip { right: auto; left: -26px; }
    .widget.top .keystrip { bottom: auto; top: 36px; }
    .keystrip span { display: contents; }
    .keystrip kbd { justify-self: start; font: 600 10.5px/1 ui-monospace, monospace; color: #18181b; background: #f4f4f5; border: 1px solid #d4d4d8;
                    border-bottom-width: 2px; border-radius: 4px; padding: 2px 5px; }
    .keystrip .all { color: #71717a; }
    /* Which tool this is (bookmark or extension) and how it started, in words: the round button itself stays the same. */
    .label .who { display: block; text-align: left; margin-bottom: 6px; padding-bottom: 6px; border-bottom: 1px solid #3f3f46; color: #a1a1aa; font: 600 10.5px/1 system-ui, sans-serif; }
    .label .who b { color: #fff; font: inherit; }
    .grp b { color: #18181b; font: inherit; }
    .keystrip .who { display: block; grid-column: 1 / -1; margin-top: 2px; padding-top: 6px; border-top: 1px solid #e4e4e7; color: #71717a; font: 600 11px system-ui, sans-serif; }
    .keystrip .who b { color: #18181b; font: inherit; }
    .keys .who { grid-column: 1 / -1; margin-top: 6px; padding-top: 8px; border-top: 1px solid #3f3f46; color: #a1a1aa; font-size: 12px; }
    .keys .who b { grid-column: auto; margin: 0; font-size: inherit; color: #fff; }
    /* The name for shared comments: a small box right above Share (below it when the bar is at the top of the screen). */
    .ask { position: absolute; bottom: 34px; width: 252px; background: #fff; color: #18181b; border-radius: 12px; padding: 10px 10px 8px; pointer-events: auto;
           box-shadow: 0 12px 32px #0006, 0 0 0 1px #0000001a; }
    .widget.top .ask { bottom: auto; top: 34px; }
    .ask::after { content: ''; position: absolute; left: var(--ax, 50%); bottom: -6px; width: 12px; height: 12px; margin-left: -6px; background: #fff; rotate: 45deg;
                  box-shadow: 3px 3px 4px #0000001a; }
    .widget.top .ask::after { bottom: auto; top: -6px; box-shadow: -2px -2px 3px #0000001a; }
    .ask .t { display: block; font: 600 12px system-ui, sans-serif; margin: 0 2px 7px; }
    .ask form, .act.me form { display: flex; gap: 6px; flex: 1; }
    .ask input, .act.me input { flex: 1; min-width: 0; border: 1px solid #d4d4d8; border-radius: 8px; padding: 6px 9px; font: 13px system-ui, sans-serif; color: #18181b;
                                outline: none; background: #fff; }
    .ask input:focus, .act.me input { border-color: #ea580c; box-shadow: 0 0 0 3px #ea580c33; }
    .ask button, .act.me form button { border: 0; border-radius: 8px; padding: 0 12px; background: #ea580c; color: #fff; font: 700 12.5px system-ui, sans-serif; cursor: pointer; }
    .ask button:hover, .act.me form button:hover { background: #c2410c; }
    .ask .hint { display: block; margin: 7px 2px 0; color: #71717a; font: 500 11px system-ui, sans-serif; }
    .ask .hint kbd { font: 600 10px ui-monospace, monospace; color: #52525b; border: 1px solid #d4d4d8; border-bottom-width: 2px; border-radius: 3px; padding: 0 3px; background: #fafafa; }
    .act.share.held { background: #3f3f46; color: #fff; }
    .act.share.held .label { opacity: 0 !important; }
    .more-list .act.me .who-am-i { flex: 1; }
    .more-list .act.me .who-am-i b { font: 600 13px system-ui, sans-serif; }
    .more-list .act.me .who-am-i i { font-style: normal; color: #a1a1aa; }
    .more-list .act.me .chg { color: #c2410c; font: 600 12.5px system-ui, sans-serif; }
    .more-list .act.me:hover .chg { text-decoration: underline; }
    .more-list .act.me.editing, .more-list .act.me.editing:hover { background: #fff7ed; cursor: default; }
    .more-list .act.me input { padding: 3px 7px; border-radius: 7px; }
    .more-list .sub { display: block; color: #a1a1aa; font: 500 11px system-ui, sans-serif; padding: 0 8px 4px 34px; margin-top: -3px; }
    .card.toast { position: relative; padding-right: 36px; } /* room for the \xD7; .card sets the padding later */
    .toast .x { position: absolute; top: 7px; right: 7px; width: 22px; height: 22px; padding: 0; border: 0; border-radius: 50%; display: grid; place-items: center;
                background: transparent; color: #a1a1aa; cursor: pointer; }
    .toast .x:hover { background: #f4f4f5; color: #18181b; }
    .toast .x svg { width: 12px; height: 12px; }
    .toast .chg { border: 0; background: none; padding: 0; color: #c2410c; font: 600 13px system-ui, sans-serif; cursor: pointer; text-decoration: underline; text-underline-offset: 2px; }
    .more-list .label kbd { color: #71717a; border-color: #d4d4d8; background: #fafafa; }
    /* Clear all sits in the bar; armed (one more click clears) it turns red and keeps its label showing. */
    .act.clear:hover:not(:disabled) { background: #7f1d1d; } .act.clear.armed, .act.clear.armed:hover:not(:disabled) { background: #dc2626; color: #fff; } .act.clear.armed .label { opacity: 1; }
    .more-list .act.info.new { background: #dcfce7; color: #15803d; } .more-list .act.info.new svg { color: #15803d; }
    /* The comments list and messages share one column above the bar (below it near the top of the screen). */
    .dock { position: fixed; width: max-content; display: flex; flex-direction: column; gap: 8px; transition: translate .18s cubic-bezier(.2, .8, .2, 1); }
    .card, .toast { pointer-events: auto; box-shadow: 0 10px 30px #0005; }
    .toast { max-width: 340px; font-size: 13px; line-height: 1.45; } /* a message is a card, like the comments list */
    .card { background: #fff; color: #18181b; border-radius: 12px; padding: 12px; }
    .panel { width: 340px; max-height: 50vh; overflow: auto; padding: 6px; scrollbar-width: thin; scrollbar-color: #d4d4d8 transparent; }
    .panel::-webkit-scrollbar { width: 8px; } .panel::-webkit-scrollbar-thumb { background: #d4d4d8; border-radius: 4px; }
    .panel-head { display: flex; justify-content: space-between; align-items: center; padding: 4px 6px 6px; color: #71717a; font-size: 12px; }
    .panel ol { list-style: none; padding: 0; }
    .row-acts { display: flex; align-items: center; gap: 2px; }
    .one { border: 0; background: none; color: #a1a1aa; cursor: pointer; padding: 2px 4px; display: grid; place-items: center; font: 600 12px system-ui, sans-serif; }
    .one svg { width: 14px; height: 14px; } .one:hover { color: #2563eb; }
    .panel li { display: grid; grid-template-columns: 22px 1fr auto; gap: 8px; align-items: start; padding: 8px 6px; border-radius: 8px; cursor: pointer; }
    .panel li:hover { background: #f4f4f5; }
    /* Comments that came in through a shared link are purple: pins, numbers and a mild row background. */
    /* Comments from a shared link take their writer's colour (--who): pin, number, a mild row background, the box's chip. */
    .panel li.shared { background: color-mix(in srgb, var(--who) 9%, #fff); } .panel li.shared:hover { background: color-mix(in srgb, var(--who) 16%, #fff); }
    .shared .num, .pin.shared { background: var(--who); } .pin.shared:hover { filter: brightness(.88); }
    .by { flex: none; display: inline-flex; align-items: center; gap: 4px; font-size: 11px; font-weight: 600; color: var(--who); background: color-mix(in srgb, var(--who) 12%, #fff); border-radius: 999px; padding: 1px 8px 1px 6px; }
    .by::before { content: ''; width: 7px; height: 7px; border-radius: 50%; background: var(--who); }
    .name-bar input { border: 0; border-radius: 999px; padding: 4px 10px; width: 150px; font: 13px system-ui, sans-serif; color: #18181b; outline: none; }
    .num { width: 20px; height: 20px; border-radius: 50%; background: #ea580c; color: #fff; font-size: 11px; font-weight: 700; text-align: center; line-height: 20px; }
    .txt { min-width: 0; } .txt small { display: block; color: #71717a; font-size: 11px; margin-top: 2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .del { border: 0; background: none; color: #a1a1aa; cursor: pointer; font-size: 12px; padding: 0 4px; }
    .del { font-size: 16px; line-height: 20px; }
    .del:hover { color: #dc2626; }
    .empty { padding: 10px 6px; color: #71717a; }
    /* Wide enough for the hint and all four buttons (Delete, Copy, Cancel, Save) on one line; narrower only on a small screen. */
    .pop { position: fixed; width: min(380px, calc(100vw - 16px)); }
    /* The box names the pick in plain words; the technical details sit in a dark card beside it, behind a tab. */
    .head { display: flex; align-items: center; gap: 6px; margin-bottom: 8px; min-width: 0; }
    /* A batch comment's box steps through its selections: \u2039 2/3 \u203A. */
    .nav { flex: none; display: inline-flex; align-items: center; gap: 2px; }
    .nav button { width: 22px; height: 22px; padding: 0; border: 1px solid #d4d4d8; border-radius: 6px; background: #fff; color: #18181b; cursor: pointer;
                  font: 600 14px/1 system-ui, sans-serif; display: grid; place-items: center; }
    .nav button:hover { background: #f4f4f5; }
    .nav span { min-width: 30px; text-align: center; font: 600 11px ui-monospace, monospace; color: #71717a; }
    .picked.cur { outline-style: solid; outline-width: 3px; background: #2563eb24; }
    .chip { flex: none; font: 700 10px ui-monospace, monospace; color: #2563eb; background: #2563eb14; border-radius: 4px; padding: 2px 5px; }
    .what { flex: 1; min-width: 0; font-weight: 600; color: #3f3f46; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .side-tab { position: absolute; left: 100%; top: 14px; display: grid; gap: 4px; justify-items: center; border: 0; cursor: pointer; padding: 8px 6px 8px 7px;
                background: #18181b; color: #a1a1aa; border-radius: 0 8px 8px 0; box-shadow: 0 8px 20px #0004; font: 11px ui-monospace, monospace; }
    .side-tab:hover { background: #27272a; color: #e4e4e7; }
    .side { display: none; position: absolute; left: calc(100% + 8px); top: 0; width: 250px; background: #18181b; color: #e4e4e7; border-radius: 10px;
            padding: 8px 12px 10px; box-shadow: 0 12px 32px #0006; font: 11px/1.75 ui-monospace, monospace; }
    .pop.details .side { display: block; } .pop.details .side-tab { display: none; }
    .pop.flip .side-tab { left: auto; right: 100%; border-radius: 8px 0 0 8px; } .pop.flip .side { left: auto; right: calc(100% + 8px); }
    .side .k { color: #a1a1aa; display: inline-block; width: 78px; }
    .side-head { display: flex; justify-content: space-between; width: 100%; border: 0; background: none; color: #a1a1aa; cursor: pointer; padding: 0; font: inherit; }
    .side-head:hover { color: #e4e4e7; }
    .side .sep { border-top: 1px solid #3f3f46; margin: 6px 0; }
    .side .selector { color: #d4d4d8; word-break: break-all; line-height: 1.4; }
    .copy-sel { border: 0; background: none; color: #93c5fd; cursor: pointer; padding: 0; margin-top: 4px; font: inherit; }
    .copy-sel:hover { text-decoration: underline; }
    .sw { display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin: 0 4px 0 8px; vertical-align: -1px; box-shadow: 0 0 0 1px #0004, 0 0 0 2px #fff8; }
    textarea { width: 100%; min-height: 72px; border: 1px solid #d4d4d8; border-radius: 8px; padding: 8px; resize: vertical;
               background: #fff; color: #18181b; outline: none; }
    textarea:focus { border-color: #2563eb; box-shadow: 0 0 0 3px #2563eb33; }
    textarea::placeholder { color: #a1a1aa; }
    .row { display: flex; gap: 6px; margin-top: 8px; align-items: center; }
    .hint { flex: 1; min-width: 0; color: #a1a1aa; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .row button.b { flex: none; white-space: nowrap; } /* when space runs out the hint gives way, never a button */
    button.b { border: 1px solid #d4d4d8; background: #fff; color: #18181b; font-weight: 600; border-radius: 8px; padding: 6px 12px; cursor: pointer; }
    button.b:hover { background: #f4f4f5; }
    button.b.primary { background: #ea580c; color: #fff; border-color: #ea580c; }
    button.b.primary:hover { background: #c2410c; border-color: #c2410c; }
    button.b.danger { color: #dc2626; }
    /* Shift+click selections, and the keyboard shortcuts card. */
    .picked { position: fixed; pointer-events: none; outline: 2px dashed #2563eb; outline-offset: 1px; background: #2563eb12; border-radius: 2px; }
    /* Each selected box has its own remove button: a dragged area cannot be clicked off like an element. */
    .picked .x { position: absolute; top: -11px; right: -11px; width: 20px; height: 20px; padding: 0; border: 2px solid #fff; border-radius: 50%;
                 background: #2563eb; color: #fff; display: grid; place-items: center; cursor: pointer; pointer-events: auto; box-shadow: 0 2px 6px #0005; }
    .picked .x:hover { background: #dc2626; }
    .picked .x svg { width: 10px; height: 10px; stroke-width: 3; }
    .keys { position: fixed; left: 50%; bottom: 24px; translate: -50% 0; pointer-events: auto; background: #18181b; color: #e4e4e7; border-radius: 12px;
            padding: 12px 16px; box-shadow: 0 12px 32px #0006; display: grid; grid-template-columns: auto auto; gap: 4px 18px; font-size: 12px; }
    .keys b { grid-column: 1 / -1; font-size: 13px; margin-bottom: 4px; }
    .keys kbd { font: 11px ui-monospace, monospace; background: #27272a; border: 1px solid #3f3f46; border-bottom-width: 2px; border-radius: 4px; padding: 0 5px; color: #fff; }
    /* Our right-click menu. */
    .menu { position: fixed; pointer-events: auto; min-width: 230px; background: #18181b; color: #e4e4e7; border-radius: 10px; padding: 6px; box-shadow: 0 12px 32px #0006; }
    .mh { display: flex; align-items: center; gap: 8px; padding: 4px 6px 8px; font: 11px ui-monospace, monospace; color: #a1a1aa; }
    .mh .t { background: #2563eb; color: #fff; padding: 3px 6px; border-radius: 5px; font-weight: 700; }
    .mi { display: flex; justify-content: space-between; gap: 16px; width: 100%; border: 0; background: none; color: #e4e4e7; padding: 7px 8px; border-radius: 6px; cursor: pointer; text-align: left; }
    .mi:hover { background: #2563eb; color: #fff; }
    .mk { color: #71717a; font: 11px ui-monospace, monospace; } .mi:hover .mk { color: #dbeafe; }
    .menu hr { border: 0; border-top: 1px solid #3f3f46; margin: 4px 2px; }
    /* Freeze: the picture of the screen at the moment of freezing, shown over the page. Its bar sits at the bottom, like
       the Select several bar: menus and tooltips, the things people freeze, mostly open near the top. */
    .freeze-layer { position: fixed; inset: 0; pointer-events: auto; cursor: pointer; } /* as on the live page while commenting */
    .freeze-layer canvas { position: absolute; inset: 0; width: 100%; height: 100%; }
    .freeze-bar { position: absolute; left: 50%; bottom: 18px; translate: -50% 0; display: flex; gap: 10px; align-items: center; background: #0284c7; color: #fff;
                  padding: 6px 6px 6px 14px; border-radius: 999px; font-weight: 600; box-shadow: 0 6px 18px #0005; cursor: default; white-space: nowrap; }
    .freeze-bar button { border: 0; background: #fff; color: #0369a1; font-weight: 700; border-radius: 999px; padding: 4px 12px; cursor: pointer; }
    .pick-bar { position: fixed; pointer-events: auto; background: #2563eb; } .pick-bar button { color: #1d4ed8; }
    .pick-bar button:disabled { opacity: .5; cursor: default; }
    .act.freeze.active { background: #0284c7; color: #fff; }
    /* Area mode: a crosshair layer over the page, and the dashed box being dragged (kept while its comment is open). */
    .area-layer { position: fixed; inset: 0; pointer-events: auto; cursor: crosshair; }
    .area-box { position: fixed; pointer-events: none; border: 2px dashed #2563eb; background: #2563eb14; border-radius: 2px; }
    .act.area.active { background: #2563eb; color: #fff; }
    .snap { display: flex; align-items: center; gap: 6px; margin-top: 8px; color: #3f3f46; font-size: 12px; cursor: pointer; user-select: none; }
    /* Our own checkbox: the native one looks different on every site and system. */
    .snap input { appearance: none; margin: 0; flex: none; width: 16px; height: 16px; border: 1.5px solid #a1a1aa; border-radius: 5px; background: #fff;
                  display: grid; place-content: center; cursor: pointer; transition: background .15s, border-color .15s; }
    .snap input::before { content: ''; width: 10px; height: 10px; background: #fff; transform: scale(0); transition: transform .12s;
                          clip-path: polygon(14% 44%, 0 62%, 42% 100%, 100% 18%, 84% 4%, 40% 66%); }
    .snap:hover input { border-color: #2563eb; }
    .snap input:checked { background: #2563eb; border-color: #2563eb; }
    .snap input:checked::before { transform: scale(1); }
    .snap input:focus-visible { outline: 2px solid #2563eb66; outline-offset: 2px; }
    .snap { width: fit-content; } /* only the tick and its words, so the row around it stays free to hover */
    .snap.off { cursor: default; } .snap.off > input, .snap.off > span:not(.shot-q) { opacity: .55; } .snap.off input { cursor: not-allowed; }
    .shot-q { width: 16px; height: 16px; border-radius: 50%; display: grid; place-items: center; cursor: help; flex: none; outline: none;
              background: #e4e4e7; color: #3f3f46; font: 700 10px/1 system-ui, sans-serif; }
    .shot-q:hover, .shot-q:focus-visible { background: #18181b; color: #fff; }
    /* Why Add screenshot is off: a dark card under the comment box (over it when the box is at the bottom of the screen),
       so it never covers the text. It opens from the ? only, and stays a moment after the pointer leaves, so the pointer
       can reach it to select the chrome://flags address. */
    .shot-tip { position: absolute; left: 0; top: calc(100% + 8px); width: 100%; box-sizing: border-box; background: #18181b;
                color: #e4e4e7; font: 400 12px/1.5 system-ui, sans-serif; padding: 10px 12px; border-radius: 10px; user-select: text;
                box-shadow: 0 8px 24px #0005; opacity: 0; visibility: hidden; transition: opacity .15s .3s, visibility 0s .45s; }
    .shot-tip::before { content: ''; position: absolute; left: 0; right: 0; bottom: 100%; height: 8px; } /* bridges the gap */
    .pop.tip-up .shot-tip { top: auto; bottom: calc(100% + 8px); } .pop.tip-up .shot-tip::before { bottom: auto; top: 100%; }
    .pop:has(.shot-q:hover, .shot-q:focus-visible, .shot-tip:hover) .shot-tip { opacity: 1; visibility: visible; transition-delay: 0s; }
    .shot-tip b { display: block; color: #fff; font-weight: 600; margin-bottom: 2px; }
    .shot-tip p { margin: 6px 0 0; } .shot-tip ol { margin: 4px 0 0; padding-left: 18px; }
    .shot-tip code { font: 11px ui-monospace, monospace; color: #fff; background: #3f3f46; border-radius: 4px; padding: 1px 4px; overflow-wrap: anywhere; }
    button.b:disabled, button.b:disabled:hover { background: #f4f4f5; color: #a1a1aa; border-color: #f4f4f5; cursor: not-allowed; }
  `);
    root.adoptedStyleSheets = [sheet];
    const h = (tag, props, ...kids) => {
      const el = Object.assign(document.createElement(tag), props);
      el.append(...kids);
      return el;
    };
    const btn = (textContent, className = "", title = "") => h("button", { textContent, className, title });
    const pill = h("div", { className: "pill" }), more = h("div", { className: "more" });
    const hl = h("div", { className: "hl", hidden: true }, pill, more);
    const pins = h("div");
    const kindEl = h("span", { className: "chip" }), nameEl = h("span", { className: "what" }), byEl = h("span", { className: "by", hidden: true });
    const navPrev = btn("\u2039", "", "Previous selection"), navNext = btn("\u203A", "", "Next selection"), navPos = h("span");
    const navEl = h("span", { className: "nav", hidden: true }, navPrev, navPos, navNext);
    const sideTab = h("button", { className: "side-tab", title: "Details: colours, font, spacing, selector (D)" });
    const sideHead = h("button", { className: "side-head" }, h("span", { textContent: "details" }), h("span", { textContent: "\u2039" }));
    const sideBody = h("div"), selectorEl = h("div", { className: "selector" }), copySelBtn = btn("copy selector", "copy-sel");
    const side = h("div", { className: "side" }, sideHead, sideBody, h("div", { className: "sep" }), selectorEl, copySelBtn);
    const textarea = h("textarea", { placeholder: "What should change here?", dir: "auto" });
    const deleteBtn = btn("Delete", "b danger"), cancelBtn = btn("Cancel", "b"), saveBtn = btn("Save", "b primary");
    const boxCopyBtn = btn("Copy", "b", "Copy this comment as it is now, with a picture if Add screenshot is ticked, without saving it");
    const shotBox = h("input", { type: "checkbox" });
    const shotLabel = h("label", { className: "snap" }, shotBox, h("span", { textContent: "Add screenshot" }));
    const canShoot = platform.capture.available !== false;
    let shotTip = null;
    if (!canShoot) {
      shotBox.disabled = true;
      shotLabel.classList.add("off");
      const code = (t) => h("code", { textContent: t });
      shotTip = h(
        "div",
        { className: "shot-tip", id: "shot-tip", role: "tooltip" },
        h("b", { textContent: "No pictures on this page" }),
        "It is plain http, and browsers allow screen capture only on https or localhost pages.",
        h("p", { textContent: "To allow it in Chrome:" }),
        h(
          "ol",
          {},
          h("li", {}, "Open ", code("chrome://flags/#unsafely-treat-insecure-origin-as-secure")),
          h("li", {}, "Add ", code(location.origin), ", choose Enabled and relaunch.")
        ),
        h("p", { textContent: "Or open your site as localhost or name.localhost, or use the page-comments extension." })
      );
      const q = h("span", { className: "shot-q", textContent: "?", tabIndex: 0, ariaLabel: "Why no pictures?" });
      q.setAttribute("aria-describedby", "shot-tip");
      shotLabel.append(q);
      shotBox.setAttribute("aria-describedby", "shot-tip");
      shotBox.ariaLabel = "Add screenshot";
      const aim = () => pop.classList.toggle("tip-up", pop.getBoundingClientRect().bottom + shotTip.offsetHeight + 16 > innerHeight);
      q.addEventListener("pointerenter", aim);
      q.addEventListener("focus", aim);
    }
    const pop = h(
      "div",
      { className: "card pop", hidden: true },
      h("div", { className: "head" }, kindEl, nameEl, byEl, navEl),
      textarea,
      shotLabel,
      h("div", { className: "row" }, h("span", { className: "hint", textContent: "Enter saves" }), deleteBtn, boxCopyBtn, cancelBtn, saveBtn),
      sideTab,
      side,
      shotTip ?? ""
    );
    const toastEl = h("div", { className: "card toast", hidden: true });
    const list = h("ol");
    const textBtn = h("button", { className: "one", textContent: "Copy text", title: "Only the text, no pictures: for Jira and Confluence" });
    const picsBtn = h("button", { className: "one", textContent: "Copy pictures", title: "Only the pictures: paste them after the text" });
    const filesBtn = h("button", { className: "one", textContent: "Save pictures", title: "Each picture as its own file, to drag into Slack together" });
    const panel = h("div", { className: "card panel", hidden: true }, h(
      "div",
      { className: "panel-head" },
      h("span", { textContent: "Comments" }),
      h("span", { className: "row-acts" }, textBtn, picsBtn, filesBtn)
    ), list);
    const svg = (tag, attrs, ...kids) => {
      const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
      for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
      el.append(...kids);
      return el;
    };
    const ICONS = {
      person: [["circle", { cx: 12, cy: 8, r: 4 }], ["path", { d: "M4 21c0-4 3.6-7 8-7s8 3 8 7" }]],
      // The page-comments icon (icons/icon.svg) as an outline: a comment bubble with a cursor in it.
      comment: [["path", { d: "M3 3h18a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-8l-5 4v-4H3a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z", "stroke-width": 1.8 }], ["path", { d: "M7.4 5.2L12.16 17.44L13.86 12.51L18.79 10.81Z", fill: "currentColor", stroke: "none" }]],
      browse: [["path", { d: "M5 3l6.5 17 2.3-7.2L21 10.5z" }]],
      list: [["path", { d: "M8 6h13M8 12h13M8 18h13M4 6h.01M4 12h.01M4 18h.01" }]],
      copy: [["rect", { x: 9, y: 9, width: 12, height: 12, rx: 2 }], ["path", { d: "M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1" }]],
      send: [["path", { d: "M22 2L11 13M22 2l-7 20-4-9-9-4z" }]],
      clear: [["path", { d: "M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" }]],
      info: [["circle", { cx: 12, cy: 12, r: 9 }], ["path", { d: "M12 11v6M12 7.5v.5" }]],
      close: [["path", { d: "M6 6l12 12M18 6L6 18" }]],
      dots: [["circle", { cx: 5, cy: 12, r: 1.5, fill: "currentColor" }], ["circle", { cx: 12, cy: 12, r: 1.5, fill: "currentColor" }], ["circle", { cx: 19, cy: 12, r: 1.5, fill: "currentColor" }]],
      details: [["path", { d: "M4 7h16M4 12h10M4 17h7" }]],
      shortcuts: [["rect", { x: 2, y: 6, width: 20, height: 12, rx: 2 }], ["path", { d: "M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10" }]],
      area: [["path", { d: "M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4" }], ["rect", { x: 9, y: 9, width: 6, height: 6, rx: 1 }]],
      share: [["path", { d: "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" }]],
      batch: [["rect", { x: 3, y: 3, width: 8, height: 8, rx: 1.5 }], ["rect", { x: 13, y: 3, width: 8, height: 8, rx: 1.5 }], ["rect", { x: 3, y: 13, width: 8, height: 8, rx: 1.5 }], ["path", { d: "M17 13v8M13 17h8" }]],
      freeze: [["path", { d: "M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7M9 4l3 2 3-2M9 20l3-2 3 2" }]]
    };
    const icon = (name) => svg(
      "svg",
      { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true" },
      ...ICONS[name].map(([tag, attrs]) => svg(tag, attrs))
    );
    const badge = h("span", { className: "badge", hidden: true });
    const updateDot = h("span", { className: "dot", hidden: true });
    const mainTip = h("span", { className: "label" });
    const TOOL = platform.name === "extension" ? "Extension" : "Bookmark", SHOWN_VERSION = /^\d/.test(VERSION) ? " " + VERSION : "";
    const VIA = platform.startedBy === "bookmark" ? "started from your bookmark" : "";
    const who = (before, sep2) => h("span", { className: "who" }, before, h("b", { textContent: TOOL }), SHOWN_VERSION + (VIA ? sep2 + VIA : ""));
    const main = h("button", { className: "main" }, icon("comment"), badge, updateDot, mainTip);
    const ACT_KEYS = { area: "A", batch: "B", freeze: "F", list: "L", copy: "C", share: "S", details: "D", shortcuts: "?" };
    const action = (name, label, tag = "button", props = {}) => {
      const labelEl = h("span", { textContent: label });
      const el = h(
        tag,
        { className: "act " + name, ariaLabel: label + (ACT_KEYS[name] ? ` (${ACT_KEYS[name]})` : ""), ...props },
        icon(name),
        h("span", { className: "label" }, labelEl, ...ACT_KEYS[name] ? [h("kbd", { textContent: ACT_KEYS[name] })] : [])
      );
      el.labelEl = labelEl;
      el.baseLabel = label;
      return el;
    };
    const ALT_SHIFT = /Mac|iPhone|iPad/.test(navigator.platform) ? "\u2325\u21E7" : "Alt+Shift+";
    const FREEZE_LABEL = "Freeze: 3 s to open a menu first";
    const listBtn = action("list", "Comments"), copyBtn = action("copy", "Copy"), sendBtn = action("send", "Send to Claude", "button", { hidden: true });
    const clearBtn = action("clear", "Clear all"), closeBtn = action("close", "Close"), areaBtn = action("area", "Select an area"), freezeBtn = action("freeze", FREEZE_LABEL);
    const batchBtn = action("batch", "Select several"), shareBtn = action("share", "Share link");
    const infoLink = action("info", (fromGithub ? "Help & install on GitHub \xB7 v" : "Help & install page \xB7 v") + VERSION, "a", { href: fromGithub ? GITHUB + "#-three-ways-to-use-it" : SITE, target: "_blank", rel: "noopener noreferrer" });
    const detailsAct = action("details", "Details: colours, font, spacing"), keysAct = action("shortcuts", "Keyboard shortcuts"), moreBtn = action("dots", "More");
    areaBtn.append(h("span", { className: "ontxt", textContent: "Area" }));
    batchBtn.append(h("span", { className: "ontxt", textContent: "Batch" }));
    freezeBtn.append(h("span", { className: "ontxt", textContent: "Frozen" }));
    const listCnt = h("span", { className: "cnt", hidden: true });
    listBtn.append(listCnt);
    const sep = () => h("i", { className: "sep" });
    const meRow = h("div", { className: "act me" });
    const KEPT = platform.saveName ? "Asked once, used on every site." : "Saved for this site only.";
    const moreList = h(
      "div",
      { className: "more-list" },
      h("div", { className: "grp" }, h("b", { textContent: TOOL }), SHOWN_VERSION && " \xB7" + SHOWN_VERSION, VIA && " \xB7 from your bookmark"),
      detailsAct,
      keysAct,
      meRow,
      h("span", { className: "sub", textContent: KEPT.replace("Asked once, used", "Used") }),
      infoLink,
      closeBtn
    );
    const items = h("div", { className: "items" }, areaBtn, batchBtn, freezeBtn, sep(), clearBtn, listBtn, copyBtn, shareBtn, sendBtn, sep(), moreBtn);
    const keyStrip = h(
      "div",
      { className: "keystrip", hidden: true },
      ...[["B", "batch"], ["A", "area"], ["F", "freeze"], ["Esc", "browse"], ["?", "all keys"]].map(([k, what]) => h("span", { className: k === "?" ? "all" : "" }, h("kbd", { textContent: k }), what)),
      who("", " \xB7 ")
    );
    const quickClose = h("button", { className: "quick-close", ariaLabel: "Close page-comments" }, svg("svg", { viewBox: "0 0 12 12", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linecap": "round", "aria-hidden": "true" }, svg("path", { d: "M2 2l8 8M10 2l-8 8" })));
    const widget = h("div", { className: "widget" }, moreList, keyStrip, quickClose, h("div", { className: "bar" }, items, main));
    const dock = h("div", { className: "dock" }, panel, toastEl);
    const areaLayer = h("div", { className: "area-layer", hidden: true });
    const areaBox = h("div", { className: "area-box", hidden: true });
    const menu = h("div", { className: "menu", hidden: true });
    const unfreezeBtn = h("button", { textContent: "Unfreeze" });
    const freezeLayer = h(
      "div",
      { className: "freeze-layer", hidden: true },
      h("div", { className: "freeze-bar" }, "Frozen: click or drag to comment, right-click for options, Esc to unfreeze", unfreezeBtn)
    );
    const pickedBoxes = h("div"), shownBoxes = h("div");
    const pickCount = h("span"), pickComment = h("button", { textContent: "Comment" }), pickClear = h("button", { textContent: "Clear" });
    const pickBar = h("div", { className: "freeze-bar pick-bar", hidden: true }, pickCount, pickComment, pickClear);
    const KEYS = [
      ["\u2191 / \u2193", "parent / inner element"],
      ["Enter", "comment on the highlighted element"],
      ["B", "batch: click to select several (A: drag areas), then comment"],
      ["Shift+click", "start a batch with this element"],
      ["Space", "in a batch: add or remove the outlined element (\u2191 first for its parent)"],
      ["A", "select an area"],
      ["F", "freeze or unfreeze"],
      ["D", "details on / off: colours, font, spacing"],
      ["C", "copy all comments"],
      ["S", "share link (Shift+S: change your name)"],
      ["L", "comments list"],
      ["Esc", "back out"],
      [ALT_SHIFT + "F", "freeze, in any mode"],
      [ALT_SHIFT + "C", "commenting / browsing, in any mode"],
      ["?", "this card"]
    ];
    const keysCard = h(
      "div",
      { className: "keys", hidden: true },
      h("b", { textContent: "Keyboard shortcuts (while commenting)" }),
      ...KEYS.flatMap(([k, what]) => [h("span", {}, ...k.split(" / ").flatMap((x, i) => [i ? " / " : "", h("kbd", { textContent: x })])), h("span", { textContent: what })]),
      who("Page Comments \xB7 ", " \xB7 ")
    );
    let openBefore = [], toastBefore = false;
    const syncOpen = () => {
      const open = [!panel.hidden, !pop.hidden, !menu.hidden, !keysCard.hidden, widget.classList.contains("listopen"), shareBtn.classList.contains("held")];
      if (toastBefore && open.some((on, i) => on && !openBefore[i])) toastEl.hidden = true;
      openBefore = open;
      toastBefore = !toastEl.hidden;
      const hide = !(main.classList.contains("on") && pop.hidden && menu.hidden && panel.hidden && toastEl.hidden && !widget.classList.contains("open"));
      if (keyStrip.hidden !== hide) keyStrip.hidden = hide;
    };
    new MutationObserver(syncOpen).observe(root, { subtree: true, attributes: true, attributeFilter: ["hidden", "class"] });
    widget.addEventListener("click", () => {
      toastEl.hidden = true;
    }, true);
    root.append(freezeLayer, hl, shownBoxes, areaLayer, areaBox, pickedBoxes, pins, pickBar, pop, dock, menu, keysCard, widget);
    document.documentElement.appendChild(host);
    const pageOf = () => pageKey(location.href);
    const here = () => {
      const page2 = pageOf();
      return comments.filter((c) => pageKey(c.page) === page2);
    };
    const KEY = "page-comments:v1";
    const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    const load = () => {
      try {
        return (JSON.parse(localStorage.getItem(KEY)) || []).map((c) => ({ id: newId(), ...c }));
      } catch {
        return [];
      }
    };
    let comments = load(), saveFailed = false;
    const persist = () => {
      try {
        localStorage.setItem(KEY, JSON.stringify(comments, (k, v) => k === "el" ? void 0 : v));
        saveFailed = false;
      } catch (err) {
        if (!saveFailed) toast("Could not save comments in this site (" + err.message + "). A reload will lose them.");
        saveFailed = true;
      }
    };
    const docIn = (frames) => frames.reduce((doc, s) => doc.querySelector(s).contentDocument, document);
    const find = (selector) => {
      try {
        const frames = selector.split(FRAME_SEP), own = frames.pop();
        return docIn(frames).querySelector(own);
      } catch {
        return null;
      }
    };
    const frameOf = (doc) => doc !== document && doc.defaultView?.frameElement || null;
    const offsetOf = (doc) => {
      let x = 0, y = 0;
      for (let f; f = frameOf(doc); doc = f.ownerDocument) {
        const r = f.getBoundingClientRect(), cs = getComputedStyle(f);
        x += r.left + f.clientLeft + parseFloat(cs.paddingLeft);
        y += r.top + f.clientTop + parseFloat(cs.paddingTop);
      }
      return { x, y };
    };
    const rectOf = (el) => {
      const r = el.getBoundingClientRect(), o = offsetOf(el.ownerDocument);
      return new DOMRect(r.x + o.x, r.y + o.y, r.width, r.height);
    };
    const pointOf = (e) => {
      const o = offsetOf(e.target.ownerDocument || e.target);
      return { x: e.clientX + o.x, y: e.clientY + o.y };
    };
    const up = (el) => {
      const p = el.parentElement;
      return p && p !== p.ownerDocument.documentElement ? p : frameOf(el.ownerDocument);
    };
    const holds = (a, el) => {
      for (; el; el = up(el)) if (el === a) return true;
      return false;
    };
    const elOf = (c) => c.el?.isConnected && c.el.ownerDocument.defaultView ? c.el : c.el = find(c.selector);
    const SHOT_KEY = "page-comments:shot";
    const shotRect = (el, area, m = 24) => {
      const r = rectOf(el);
      if (area) return { left: r.left + area.dx - 8, top: r.top + area.dy - 8, right: r.left + area.dx + area.w + 8, bottom: r.top + area.dy + area.h + 8 };
      return { left: r.left - m, top: r.top - m, right: r.right + m, bottom: r.bottom + m };
    };
    const showRect = (el, rect) => {
      el.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
      const r = rect(), by = (lo, hi, size) => lo >= 0 && hi <= size ? 0 : hi - lo > size ? lo : lo - (size - (hi - lo)) / 2;
      const dx = by(r.left, r.right, innerWidth), dy = by(r.top, r.bottom, innerHeight);
      if (dx || dy) scrollBy({ left: dx, top: dy, behavior: "instant" });
    };
    const scrollBack = (x, y) => scrollTo({ left: x, top: y, behavior: "instant" });
    const crop = async (source, k, r) => {
      const out = Math.min(k, 2), x = Math.max(0, r.left), y = Math.max(0, r.top);
      const w = Math.min(innerWidth, r.right) - x, ht = Math.min(innerHeight, r.bottom) - y;
      if (w <= 0 || ht <= 0) throw new Error("it is not on the screen");
      const sx = Math.round(x * k), sy = Math.round(y * k), sw = Math.round(w * k), sh = Math.round(ht * k), scale = out / k;
      const canvas = h("canvas", { width: Math.round(sw * scale), height: Math.round(sh * scale) });
      canvas.getContext("2d").drawImage(source, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise((ok) => canvas.toBlob(ok, platform.pictureType || "image/webp", 0.9));
      return { blob, width: Math.round(w) };
    };
    const shoot = async (rect) => {
      if (!platform.capture.ready()) await platform.capture.start();
      host.style.visibility = "hidden";
      for (const doc of [document, ...linked.keys()]) doc.getSelection()?.removeAllRanges();
      if (document.activeElement && document.activeElement !== document.body && document.activeElement !== host) document.activeElement.blur();
      try {
        await new Promise(requestAnimationFrame);
        const { source, k } = await platform.capture.grab();
        return await crop(source, k, rect());
      } finally {
        host.style.visibility = "";
      }
    };
    const db = new Promise((ok, fail) => {
      const req = indexedDB.open("page-comments", 1);
      req.onupgradeneeded = () => req.result.createObjectStore("shots");
      req.onsuccess = () => {
        req.result.onversionchange = () => req.result.close();
        ok(req.result);
      };
      req.onerror = () => fail(req.error);
    });
    db.catch(() => {
    });
    const shots = async (mode, run) => {
      const store = (await db).transaction("shots", mode).objectStore("shots");
      return new Promise((ok, fail) => {
        const req = run(store);
        req.onsuccess = () => ok(req.result);
        req.onerror = () => fail(req.error);
      });
    };
    const putShot = (id, blob) => shots("readwrite", (st) => st.put(blob, id));
    const dropShot = (id) => shots("readwrite", (st) => st.delete(id)).catch(() => {
    });
    const pageShots = async () => {
      const found = /* @__PURE__ */ new Map();
      for (const c of here()) {
        if (!c.shot) continue;
        const v = await shots("readonly", (st) => st.get(c.id)).catch(() => null);
        if (v) found.set(c, Array.isArray(v) ? v : [{ blob: v, width: c.shotWidth }]);
        else c.shot = false;
      }
      return found;
    };
    const tagOf = (pics, k) => pics.length < 2 ? "" : k < 26 ? String.fromCharCode(97 + k) : "-" + (k + 1);
    const numbered = (only) => here().map((c, i) => ({ c, n: i + 1 })).filter((x) => !only || only.includes(x.c));
    const writeClipboard = async ({ text, html: html2, png: png2 }) => {
      if (navigator.clipboard) {
        if (!html2 && !png2) return navigator.clipboard.writeText(text);
        const parts = {};
        if (text != null) parts["text/plain"] = new Blob([text], { type: "text/plain" });
        if (html2) parts["text/html"] = new Blob([html2], { type: "text/html" });
        if (png2) parts["image/png"] = png2;
        return navigator.clipboard.write([new ClipboardItem(parts)]);
      }
      if (text == null) [text, html2] = ["", `<img src="${await dataUrl(png2)}" alt="">`];
      const put = (e) => {
        e.preventDefault();
        e.clipboardData.setData("text/plain", text);
        if (html2) e.clipboardData.setData("text/html", html2);
      };
      document.addEventListener("copy", put, true);
      try {
        if (!document.execCommand("copy")) throw new Error("the browser refused to copy here");
      } finally {
        document.removeEventListener("copy", put, true);
      }
    };
    const dataUrl = (blob) => new Promise((ok) => {
      const r = new FileReader();
      r.onload = () => ok(r.result);
      r.readAsDataURL(blob);
    });
    const captioned = async ({ c, n }, { blob, width: cssWidth }, tag = "", numberOnly = false) => {
      const pic = await createImageBitmap(blob), k = cssWidth ? pic.width / cssWidth : 1, band = Math.round(28 * k);
      const width = Math.max(pic.width, Math.round(240 * k));
      const canvas = h("canvas", { width, height: band + pic.height });
      const g = canvas.getContext("2d");
      g.fillStyle = "#ffffff";
      g.fillRect(0, 0, width, canvas.height);
      g.fillStyle = "#18181b";
      g.fillRect(0, 0, width, band);
      g.fillStyle = "#ffffff";
      g.font = `600 ${Math.round(13 * k)}px system-ui, sans-serif`;
      let label = numberOnly ? `${n}${tag}` : `${n}${tag} \xB7 ${c.comment}`;
      while (label.length > 4 && g.measureText(label).width > width - 20 * k) label = label.slice(0, -2) + "\u2026";
      g.fillText(label, 10 * k, band * 0.68);
      g.drawImage(pic, 0, band);
      return canvas;
    };
    const png = (canvas) => new Promise((ok) => canvas.toBlob(ok, "image/png"));
    const contactSheet = async (items2, found) => {
      const parts = await Promise.all(items2.flatMap((x) => (found.get(x.c) || []).map((p, k, all) => captioned(x, p, tagOf(all, k)))));
      const canvas = h("canvas", { width: Math.max(...parts.map((p) => p.width)), height: parts.reduce((sum, p) => sum + p.height + 8, 0) });
      const g = canvas.getContext("2d");
      let top = 0;
      for (const p of parts) {
        g.drawImage(p, 0, top);
        top += p.height + 8;
      }
      return png(canvas);
    };
    let commenting = false, draft = null, toastTimer = 0, frame = 0, clearTimer = 0, page = pageOf();
    let dodge = null;
    const selectorOf = (el) => {
      const parts = [], doc = el.ownerDocument, frame2 = frameOf(doc);
      for (; el && el.nodeType === 1 && el !== doc.documentElement; el = el.parentElement) {
        if (el.id) {
          parts.unshift("#" + CSS.escape(el.id));
          break;
        }
        let part = el.tagName.toLowerCase();
        const same = el.parentElement ? [...el.parentElement.children].filter((c) => c.tagName === el.tagName) : [];
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(el) + 1})`;
        parts.unshift(part);
      }
      return (frame2 ? selectorOf(frame2) + FRAME_SEP : "") + parts.join(" > ");
    };
    const textOf = (el) => {
      if (el.getClientRects().length) return el.innerText;
      const words = [], walk = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
      while (walk.nextNode()) {
        const t = walk.currentNode.data.trim();
        if (t && !/^(SCRIPT|STYLE|TEMPLATE)$/.test(walk.currentNode.parentNode.nodeName)) words.push(t);
      }
      return words.join(" ");
    };
    const clip = (s, n) => (s = (s || "").replace(/\s+/g, " ").trim()).length > n ? s.slice(0, n) + "\u2026" : s;
    const pickOf = (d) => {
      if (d.group) return { kind: "group", name: `${d.items.length} elements selected` };
      if (d.area) return { kind: "region", name: `${d.items.length} element${d.items.length === 1 ? "" : "s"}` };
      if (d.selectedText) return { kind: "text", name: `\u201C${clip(d.selectedText, 60)}\u201D` };
      const el = d.el, kind = el ? el.tagName.toLowerCase() : ((d.html || "").match(/^<([\w-]+)/) || [, "element"])[1];
      const label = clip(el ? textOf(el) || ["aria-label", "alt", "title", "placeholder"].map((a) => el.getAttribute(a)).find(Boolean) : d.text, 60);
      return { kind, name: label ? `\u201C${label}\u201D` : kind };
    };
    const labelOf = (el) => el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (typeof el.className === "string" && el.className.trim() ? "." + el.className.trim().split(/\s+/)[0] : "");
    const hex = (rgb) => "#" + (rgb.match(/[\d.]+/g) || []).map((v, i) => (i < 3 ? +v : Math.round(v * 255)).toString(16).padStart(2, "0")).join("").replace(/^(.{6})ff$/, "$1");
    const backgroundOf = (el, seen) => {
      const walked = [], done = (v) => {
        walked.forEach((w) => seen?.set(w, v));
        return v;
      };
      for (let e = el; e && e.nodeType === 1; e = e.parentElement || frameOf(e.ownerDocument)) {
        if (seen?.has(e)) return done(seen.get(e));
        walked.push(e);
        const c = getComputedStyle(e).backgroundColor;
        if (c !== "transparent" && !/,\s*0\)$/.test(c)) return done(hex(c));
      }
      return done("#ffffff");
    };
    const luminance = (h6) => [1, 3, 5].map((i) => parseInt(h6.slice(i, i + 2), 16) / 255).map((v) => v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4).reduce((sum, v, i) => sum + v * [0.2126, 0.7152, 0.0722][i], 0);
    const contrast = (a, b) => {
      const [x, y] = [luminance(a), luminance(b)].sort((p, q) => q - p);
      return (x + 0.05) / (y + 0.05);
    };
    const sides = (v) => v.every((x) => x === v[0]) ? v[0] : v[0] === v[2] && v[1] === v[3] ? `${v[0]} ${v[1]}` : v.join(" ");
    const inspect = (el, seen) => {
      const r = el.getBoundingClientRect(), cs = getComputedStyle(el), px = (v) => String(Math.round(parseFloat(v) || 0));
      const background = backgroundOf(el, seen), color = hex(cs.color), size = parseFloat(cs.fontSize), weight = +cs.fontWeight || 400;
      const ratio = contrast(color, background), large = size >= 24 || size >= 18.66 && weight >= 700;
      return {
        label: labelOf(el),
        size: `${Math.round(r.width)}\xD7${Math.round(r.height)}`,
        background,
        color,
        font: `${px(cs.fontSize)}px ${weight} ${cs.fontFamily.split(",")[0].replace(/["']/g, "").trim()}`,
        padding: sides([cs.paddingTop, cs.paddingRight, cs.paddingBottom, cs.paddingLeft].map(px)),
        radius: sides([cs.borderTopLeftRadius, cs.borderTopRightRadius, cs.borderBottomRightRadius, cs.borderBottomLeftRadius].map(px)),
        contrast: `${ratio.toFixed(1)} ${ratio >= (large ? 3 : 4.5) ? "\u2713" : "\u2717"}`
      };
    };
    const aa = (i) => h("span", { className: "aa", textContent: "Aa", style: `background:${i.background};color:${i.color}` });
    const swatch = (c) => h("span", { className: "sw", style: `background:${c}` });
    const detail = (k, ...v) => h("div", {}, h("span", { className: "k", textContent: k }), ...v);
    const details = (i) => [
      detail("background", swatch(i.background), i.background),
      detail("text", swatch(i.color), i.color),
      detail("font", i.font),
      detail("padding", i.padding),
      detail("radius", i.radius),
      detail("contrast", h("span", { className: i.contrast.endsWith("\u2713") ? "ok" : "bad", textContent: i.contrast }))
    ];
    let hlLast = null;
    const showHighlight = (r, i) => {
      hlLast = [r, i];
      Object.assign(hl.style, { left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px" });
      pill.replaceChildren(h("span", { className: "t", textContent: i.label }), i.size.replace("\xD7", " \xD7 "), aa(i), h("span", { className: "dim", textContent: i.background }), h("kbd", { textContent: "D" }));
      more.replaceChildren(...details(i));
      hl.classList.toggle("below", r.top < (detailsOn ? 170 : 34));
      hl.hidden = false;
      for (const el of [pill, more]) el.style.left = Math.min(-2, innerWidth - 8 - r.left - el.offsetWidth) + "px";
    };
    const looks = (i, labelled) => [
      ["Size", `${i.size} px`],
      ["Background", i.background],
      ["Text", i.color],
      ["Font", i.font],
      ...[["Padding", i.padding], ["Radius", i.radius]].filter(([, v]) => v && v !== "0")
    ].map(([k, v]) => labelled ? `${k}: ${v}` : k === "Size" ? v : `${k.toLowerCase()} ${v}`).join(" \xB7 ");
    const named = (selector) => {
      const frames = selector.split(FRAME_SEP), own = `\`${shortSelector(frames.pop())}\``;
      if (!frames.length) return own;
      let url = "";
      try {
        url = docIn(frames).URL;
      } catch {
      }
      return `${own} inside the frame ${frames.map((f) => `\`${shortSelector(f)}\``).join(" \u203A ")}${/^(https?|file):/.test(url) ? ` (its page: ${url})` : ""}`;
    };
    const toText = (items2 = numbered()) => {
      const body = items2.map(({ c, n }) => [
        `## ${n}. ${c.comment}${c.by ? ` (from ${c.by})` : ""}`,
        ...c.area ? [
          c.group ? `- ${c.items.length} elements selected together, inside ${named(c.selector)}:` : `- Area over ${named(c.selector)}, covering ${c.items.length} element(s):`,
          ...c.items.map((it) => `  - ${named(it.selector)}: "${it.text}"`)
        ] : [`- Element: ${named(c.selector)}`, c.selectedText && `- Selected text: "${c.selectedText}"`, `- Element text: "${c.text}"`, `- HTML: \`${c.html}\``],
        c.info ? `- ${looks(c.info, true)}` : c.size && `- Size: ${c.size} px \xB7 Background: ${c.background}`,
        c.frozen && "- Commented on a frozen moment: the element may only show on hover or in a menu",
        c.shot && (c.shotCount > 1 ? `- Screenshots: pictures ${n}a to ${n}${tagOf({ length: c.shotCount }, c.shotCount - 1)}, one per selected element, in the order above` : `- Screenshot: picture ${n}`)
      ].filter(Boolean).join("\n")).join("\n\n");
      return `Page: ${pageOf()}

${body}`;
    };
    const esc = (t) => String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    const toHtml = async (items2, found) => {
      const pics = new Map(await Promise.all(items2.filter((x) => found.get(x.c)).map(async (x) => [
        x.c,
        await Promise.all(found.get(x.c).map(async (p, k, all) => ({ url: await dataUrl(await png(await captioned(x, p, tagOf(all, k), true))), width: p.width })))
      ])));
      const parts = items2.map(({ c, n }) => {
        const details2 = [
          c.area ? `${c.group ? "selected together inside" : "area over"} ${shortSelector(c.selector)}: ${c.items.map((it) => shortSelector(it.selector)).join(", ")}` : shortSelector(c.selector),
          c.info ? looks(c.info, false) : c.size && `${c.size} px \xB7 background ${c.background}`
        ].filter(Boolean).join(" \xB7 ");
        const img = (pics.get(c) || []).map((p) => `<p><img src="${p.url}" alt="Screenshot of comment ${n}"${p.width ? ` width="${Math.max(p.width, 240)}"` : ""}></p>`).join("");
        return `<h3>${n}. ${esc(c.comment)}${c.by ? ` <small>(from ${esc(c.by)})</small>` : ""}</h3><p>${esc(pickOf({ ...c, el: elOf(c) }).name)}</p>${img}<p style="color:#71717a;font-size:11px"><small>${esc(details2)}</small></p>`;
      });
      return `<p>Page: <a href="${esc(pageOf())}">${esc(pageOf())}</a></p>${parts.join("")}`;
    };
    const hideToast = () => {
      toastEl.hidden = true;
      clearTip(false);
    };
    const toastX = h("button", { className: "x", ariaLabel: "Close this message", title: "Close", onclick: hideToast }, icon("close"));
    const toast = (s, ms = 5e3) => {
      toastEl.replaceChildren(...[].concat(s), toastX);
      toastEl.hidden = false;
      clearTimeout(toastTimer);
      toastTimer = setTimeout(hideToast, ms);
      placeDock();
      clearTip(main.matches(":hover"));
    };
    toastEl.addEventListener("mouseenter", () => clearTimeout(toastTimer));
    toastEl.addEventListener("mouseleave", () => {
      if (!toastEl.hidden) toastTimer = setTimeout(hideToast, 4e3);
    });
    const inFrames = (doc, x, y) => {
      for (let f; f = frameOf(doc); doc = f.ownerDocument) {
        const r = rectOf(f);
        if (x < r.left || x > r.right || y < r.top || y > r.bottom) return false;
      }
      return true;
    };
    const place = () => here().forEach((c, i) => {
      const pin = pins.children[i], el = elOf(c), r = el ? rectOf(el) : { width: 0 };
      const x = r.left + Math.min(c.dx, r.width), y = r.top + Math.min(c.dy, r.height);
      pin.hidden = !r.width || !inFrames(el.ownerDocument, x, y);
      pin.style.left = x + "px";
      pin.style.top = y + "px";
    });
    const schedulePlace = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        place();
        followPop();
        drawPicked();
        drawShown();
      });
    };
    const render = () => {
      persist();
      const mine = here();
      badge.hidden = !mine.length;
      badge.textContent = mine.length;
      listBtn.labelEl.textContent = "Comments (" + mine.length + ")";
      listCnt.textContent = mine.length;
      listCnt.hidden = !mine.length;
      platform.onComments?.({ page: pageOf(), title: document.title, count: mine.length });
      copyBtn.disabled = sendBtn.disabled = clearBtn.disabled = !mine.length;
      list.replaceChildren(...mine.length ? mine.map((c, i) => h(
        "li",
        { className: c.shared ? "shared" : "", style: `--who:${colourOf(c.by)}`, title: c.shared ? "From " + (c.by || "a shared link") : "", onclick: () => edit(c) },
        h("span", { className: "num", textContent: i + 1 }),
        h("span", { className: "txt" }, c.comment, h("small", { textContent: (c.shot ? "\u{1F4F7} " : "") + (c.by ? c.by + " \xB7 " : "") + pickOf({ ...c, el: elOf(c) }).name })),
        h(
          "span",
          { className: "row-acts" },
          h("button", { className: "one", title: "Copy this comment (and its screenshot)", onclick: async (e) => {
            e.stopPropagation();
            const b = e.currentTarget;
            try {
              await copyComments([c]);
              b.textContent = "\u2713";
            } catch {
              b.textContent = "!";
            }
            setTimeout(() => {
              b.replaceChildren(icon("copy"));
            }, 1500);
          } }, icon("copy")),
          h("button", { className: "del", textContent: "\xD7", title: "Delete", onclick: (e) => {
            e.stopPropagation();
            remove(c);
          } })
        )
      )) : [h("p", { className: "empty", textContent: "No comments on this page yet. Click anything while commenting (blue button) is on." })]);
      pins.replaceChildren(...mine.map((c, i) => h("button", {
        className: c.shared ? "pin shared" : "pin",
        style: `--who:${colourOf(c.by)}`,
        textContent: i + 1,
        title: (c.shared ? `From ${c.by || "a shared link"}: ` : "") + c.comment,
        onclick: () => edit(c)
      })));
      place();
    };
    const EMBEDS = "iframe, frame, embed, object", FRAMES = "iframe, frame", LINKED = "data-page-comments-frame";
    const embedRule = `iframe:not([${LINKED}]), frame:not([${LINKED}]), embed, object { pointer-events: none !important; }
    html, body, body *, body *::before, body *::after { cursor: pointer !important; }`;
    const embedSheet = new CSSStyleSheet();
    embedSheet.replaceSync(embedRule);
    const sheets = /* @__PURE__ */ new Map([[document, embedSheet]]);
    const passEmbeds = (on) => {
      for (const [doc, sheet2] of sheets) {
        const rest = doc.adoptedStyleSheets.filter((x) => x !== sheet2);
        doc.adoptedStyleSheets = on ? [...rest, sheet2] : rest;
      }
    };
    const targetOf = (e) => [...e.target.querySelectorAll?.(EMBEDS) ?? []].reverse().find((f) => {
      const r = f.getBoundingClientRect();
      return e.clientX >= r.left && e.clientX < r.right && e.clientY >= r.top && e.clientY < r.bottom;
    }) || e.target;
    const setCommenting = (on) => {
      commenting = on;
      passEmbeds(on);
      main.classList.toggle("on", on);
      main.firstChild.replaceWith(icon(on ? "comment" : "browse"));
      main.ariaLabel = on ? "Commenting. Click to switch to browsing." : "Browsing. Click to switch to commenting.";
      mainTip.replaceChildren(who("Page Comments \xB7 ", " \xB7 "), (on ? "Click to browse the page" : "Click to comment") + " \xB7 drag to move", h("kbd", { textContent: ALT_SHIFT + "C" }));
      hl.hidden = true;
      if (!on) {
        closePop();
        panel.hidden = true;
        setArea(false);
        closeMenu();
        unfreeze();
        picked = [];
        setBatch(false);
        kbTarget = null;
      }
    };
    let areaMode = false;
    const setArea = (on) => {
      areaMode = on;
      syncLayer();
      areaBtn.classList.toggle("active", on);
      areaBtn.baseLabel = areaBtn.labelEl.textContent = on ? "Stop selecting areas" : "Select an area";
      if (on && !commenting) setCommenting(true);
      main.firstChild.replaceWith(icon(on ? "area" : batchOn ? "batch" : commenting ? "comment" : "browse"));
      drawPicked();
    };
    const openPop = (d, x, y) => {
      draft = { ...d, x, y };
      const el = d.el || d.comment && elOf(d.comment);
      const pick = pickOf({ ...d.comment || d, el });
      kindEl.textContent = pick.kind;
      nameEl.textContent = nameEl.title = pick.name + (el ? "" : " \xB7 not on the page now");
      const by = d.comment && d.comment.shared && d.comment.by;
      byEl.hidden = !by;
      byEl.textContent = by ? "by " + by : "";
      byEl.style.setProperty("--who", colourOf(d.comment && d.comment.by));
      const info = el && !d.area && (d.frozen ? d.frozen.info : inspect(el)), bg = el && (d.frozen ? d.frozen.info.background : backgroundOf(el));
      sideTab.replaceChildren(info ? aa(info) : bg ? swatch(bg) : "", "\u203A");
      sideBody.replaceChildren(...info ? [detail("size", info.size.replace("\xD7", " \xD7 ")), ...details(info)] : bg ? [detail("size", `${d.area.w} \xD7 ${d.area.h}`), detail("background", swatch(bg), bg)] : [detail("element", "not on the page now")]);
      selectorEl.textContent = d.selector;
      textarea.value = d.comment ? d.comment.comment : "";
      saveBtn.disabled = !textarea.value.trim();
      deleteBtn.hidden = !d.comment;
      let lastTick = false;
      try {
        lastTick = localStorage.getItem(SHOT_KEY) === "1";
      } catch {
      }
      shotBox.checked = canShoot && (d.comment ? !!d.comment.shot : d.area || d.frozen ? true : lastTick);
      shotLabel.hidden = !d.el;
      const many = d.group || d.comment && d.comment.group ? d.items || d.comment.items : null;
      if (many && !frozen) {
        shown = many;
        shownCur = -1;
      } else if (!d.comment && !d.area && (frozen ? d.frozen : el)) {
        shown = [frozen ? { rect: d.frozen.rect } : { selector: d.selector }];
        shownCur = -1;
      }
      navEl.hidden = !many || many.length < 2 || !!frozen;
      navPos.textContent = many ? `\u2013/${many.length}` : "";
      hl.hidden = true;
      pop.hidden = false;
      placePop(x, y, el);
      drawShown();
      textarea.focus();
    };
    let popAt = null;
    const placePop = (x, y, el) => {
      const left = Math.max(8, Math.min(x + 12, innerWidth - pop.offsetWidth - 8));
      const top = Math.max(8, Math.min(y + 12, innerHeight - pop.offsetHeight - 8));
      pop.style.left = left + "px";
      pop.style.top = top + "px";
      const r = el && !frozen ? rectOf(el) : null;
      popAt = r ? { el, dx: left - r.left, dy: top - r.top } : null;
      pop.classList.toggle("flip", pop.getBoundingClientRect().right + 266 > innerWidth);
      placeSide();
      dodgeBox();
    };
    const refitPop = () => {
      if (pop.hidden) return;
      const p = pop.getBoundingClientRect();
      placePop(p.left - 12, p.top - 12, popAt?.el);
    };
    const followPop = () => {
      if (pop.hidden || !popAt || frozen) return;
      const r = rectOf(popAt.el);
      if (!r.width && !r.height) return;
      pop.style.left = r.left + popAt.dx + "px";
      pop.style.top = r.top + popAt.dy + "px";
      if (draft.area && !areaBox.hidden) Object.assign(areaBox.style, { left: r.left + draft.area.dx + "px", top: r.top + draft.area.dy + "px" });
      placeSide();
      dodgeBox();
    };
    const goPick = (step) => {
      const n = shown.length;
      if (n < 2) return;
      shownCur = shownCur < 0 ? step > 0 ? 0 : n - 1 : (shownCur + step + n) % n;
      navPos.textContent = `${shownCur + 1}/${n}`;
      const it = shown[shownCur], el = find(it.selector);
      if (el) {
        const rect = () => {
          const r2 = rectOf(el);
          return it.box ? { left: r2.left + it.box.dx, top: r2.top + it.box.dy, right: r2.left + it.box.dx + it.box.w, bottom: r2.top + it.box.dy + it.box.h } : r2;
        };
        showRect(el, rect);
        const r = rect(), fits = r.bottom + 20 + pop.offsetHeight <= innerHeight;
        placePop(r.left, fits ? r.bottom : r.top - pop.offsetHeight - 24, el);
      }
      drawShown();
      textarea.focus();
    };
    navPrev.onclick = () => goPick(-1);
    navNext.onclick = () => goPick(1);
    const unsaved = () => !!draft && textarea.value.trim() !== (draft.comment ? draft.comment.comment : "");
    const closePop = () => {
      pop.hidden = true;
      draft = null;
      areaBox.hidden = true;
      shown = [];
      shownCur = -1;
      drawShown();
      if (dodge) {
        dodge = null;
        placeWidget();
      }
    };
    let shown = [], shownCur = -1;
    const drawShown = () => shownBoxes.replaceChildren(...shown.flatMap((it, i) => {
      const el = it.rect ? null : find(it.selector);
      if (!it.rect && !el) return [];
      const r = it.rect || rectOf(el), b = it.box ? { left: r.left + it.box.dx, top: r.top + it.box.dy, width: it.box.w, height: it.box.h } : r;
      return [h("div", { className: "picked" + (i === shownCur ? " cur" : ""), style: `left:${b.left}px;top:${b.top}px;width:${b.width}px;height:${b.height}px` })];
    }));
    const edit = (c) => {
      const el = elOf(c);
      if (!el) return openPop({ selector: c.selector + " (not found on the page now)", selectedText: c.selectedText, comment: c }, innerWidth / 2 - 150, innerHeight / 3);
      el.scrollIntoView({ block: "nearest" });
      let r = rectOf(el);
      const top = r.top + (c.area ? c.area.dy : 0), height = c.area ? c.area.h : r.height;
      if (top < 0 || top + height > innerHeight) scrollBy({ top: top + Math.min(height, innerHeight) / 2 - innerHeight / 2, behavior: "instant" });
      r = rectOf(el);
      shown = c.group ? c.items : [{ selector: c.selector, box: c.area }];
      if (c.area) openPop({ el, selector: c.selector, area: c.area, items: c.items, comment: c }, r.left + c.area.dx, r.top + c.area.dy + c.area.h);
      else openPop({ el, selector: c.selector, selectedText: c.selectedText, comment: c }, r.left + c.dx, r.top + c.dy);
      drawShown();
    };
    const remove = (c) => {
      if (c.shot) dropShot(c.id);
      comments = comments.filter((x) => x !== c);
      closePop();
      render();
    };
    const takePictures = async (c, { el, picks, rec, area }) => {
      const pad = (r, m) => ({ left: r.left - m, top: r.top - m, right: r.right + m, bottom: r.bottom + m });
      if (c.group) {
        const list2 = picks || c.items.map((it) => ({ el: find(it.selector), box: it.box })).filter((t) => t.el), pics = [];
        if (rec && frozen) for (const t of list2) pics.push(await crop(frozen.canvas, frozen.k, pad(pickRect(t), 8)));
        else {
          const sx = scrollX, sy = scrollY;
          try {
            for (const t of list2) {
              const rect = () => shotRect(t.el, t.box, 8);
              showRect(t.el, rect);
              pics.push(await shoot(rect));
            }
          } finally {
            scrollBack(sx, sy);
          }
        }
        await putShot(c.id, pics);
        c.shotCount = pics.length;
      } else {
        const { blob, width } = rec && frozen ? await crop(frozen.canvas, frozen.k, area ? pad({ left: rec.rect.left + area.dx, top: rec.rect.top + area.dy, right: rec.rect.left + area.dx + area.w, bottom: rec.rect.top + area.dy + area.h }, 8) : pad(rec.rect, 24)) : await (async () => {
          const sx = scrollX, sy = scrollY;
          const rect = () => shotRect(el, c.area);
          showRect(el, rect);
          try {
            return await shoot(rect);
          } finally {
            scrollBack(sx, sy);
          }
        })();
        await putShot(c.id, blob);
        c.shotWidth = width;
      }
      c.shot = true;
    };
    const commentFrom = (d, comment) => {
      const { el, selectedText, x, y, area, items: items2, frozen: rec, group } = d;
      if (area) {
        return {
          id: newId(),
          comment,
          el,
          page,
          dx: area.dx,
          dy: area.dy,
          area,
          items: items2,
          selector: d.selector,
          ...group ? { group } : {},
          size: `${area.w}\xD7${area.h}`,
          background: rec ? rec.info.background : backgroundOf(el),
          ...rec ? { frozen: true } : {}
        };
      }
      const r = rec ? rec.rect : rectOf(el);
      return {
        id: newId(),
        comment,
        selectedText,
        el,
        page,
        dx: Math.max(0, x - r.left),
        dy: Math.max(0, y - r.top),
        selector: d.selector,
        text: clip(textOf(el), 200),
        html: clip(el.outerHTML, 400),
        info: rec ? rec.info : inspect(el),
        ...rec ? { frozen: true } : {}
      };
    };
    const save = async () => {
      const comment = textarea.value.trim();
      if (!comment) return;
      const { el, comment: editing, area, frozen: rec, picks } = draft, wantShot = shotBox.checked;
      let c = editing;
      if (c) {
        c.comment = comment;
        if (!comments.includes(c)) comments.push(c);
      } else comments.push(c = commentFrom(draft, comment));
      closePop();
      render();
      if (!el) return;
      if (!wantShot) {
        if (c.shot) {
          c.shot = false;
          dropShot(c.id);
          render();
        }
        return;
      }
      try {
        await takePictures(c, { el, picks, rec, area });
      } catch (err) {
        toast("No screenshot: " + (err.name === "NotAllowedError" ? "sharing this tab was not allowed." : err.message));
      }
      render();
    };
    const ours = (e) => e.composedPath().includes(host);
    const onMove = (e) => {
      schedulePlace();
      if (frozen || menuState) return;
      if (!commenting || draft || ours(e)) return void (hl.hidden = true);
      if (kbTarget && holds(kbTarget.el, e.target)) return;
      kbTarget = null;
      kbStack = [];
      hovered = targetOf(e);
      showHighlight(rectOf(hovered), inspect(hovered));
    };
    const onClick = (e) => {
      if (ours(e)) return;
      if (!panel.hidden || draft && !unsaved()) {
        panel.hidden = true;
        if (!unsaved()) closePop();
        if (commenting) {
          e.preventDefault();
          e.stopPropagation();
          onMove(e);
        }
        return;
      }
      if (!commenting) return;
      e.preventDefault();
      e.stopPropagation();
      if (menuState) return closeMenu();
      if (draft) return textarea.focus();
      const { x, y } = pointOf(e);
      if (e.shiftKey || batchOn) return togglePick(kbTarget && holds(kbTarget.el, e.target) ? kbTarget : liveTarget(targetOf(e)), x, y);
      if (kbTarget && holds(kbTarget.el, e.target)) return openPop({ el: kbTarget.el, selector: kbTarget.selector }, x, y);
      const sel = e.target.ownerDocument.getSelection();
      const text = sel.toString().trim();
      const common = text && sel.getRangeAt(0).commonAncestorContainer;
      const el = text ? common.nodeType === 1 ? common : common.parentElement : targetOf(e);
      openPop({ el, selector: selectorOf(el), selectedText: text }, x, y);
    };
    const DETAILS_KEY = "page-comments:details";
    let detailsOn = false;
    try {
      detailsOn = localStorage.getItem(DETAILS_KEY) === "1";
    } catch {
    }
    const placeSide = () => {
      side.style.top = "";
      if (!detailsOn || pop.hidden) return;
      const r = side.getBoundingClientRect(), p = pop.getBoundingClientRect();
      side.style.top = Math.max(8 - p.top, Math.min(0, innerHeight - 8 - r.bottom)) + "px";
    };
    const setDetails = (on) => {
      detailsOn = on;
      pop.classList.toggle("details", on);
      hl.classList.toggle("details", on);
      if (!hl.hidden && hlLast) showHighlight(...hlLast);
      placeSide();
      try {
        localStorage.setItem(DETAILS_KEY, on ? "1" : "0");
      } catch {
      }
    };
    setDetails(detailsOn);
    sideTab.onclick = () => {
      setDetails(true);
      textarea.focus();
    };
    sideHead.onclick = () => {
      setDetails(false);
      textarea.focus();
    };
    copySelBtn.onclick = async () => {
      try {
        await writeClipboard({ text: draft.selector });
        toast("Copied " + draft.selector, 2e3);
      } catch (err) {
        toast("Could not copy (" + err.message + ")");
      }
      textarea.focus();
    };
    const editable = (t) => t && (t.isContentEditable || /^(input|textarea|select)$/i.test(t.tagName || ""));
    const onKey = (e) => {
      if (e.altKey && e.shiftKey && !e.ctrlKey && !e.metaKey && (e.code === "KeyF" || e.code === "KeyC")) {
        e.preventDefault();
        e.stopPropagation();
        return void (e.code === "KeyF" ? frozen ? unfreeze() : freeze() : setCommenting(!commenting));
      }
      if (e.key !== "Escape") {
        const t = ours(e) ? root.activeElement : e.composedPath()[0];
        if (!commenting || draft || editable(t) || e.key === "Enter" && ours(e) || e.ctrlKey || e.metaKey || e.altKey) return;
        const item = (start2) => [...menu.querySelectorAll(".mi")].find((b) => b.textContent.startsWith(start2));
        const run = menuState ? { arrowup: () => item("Select parent")?.click(), arrowdown: () => item("Select inner")?.click(), enter: () => item("Comment on this")?.click() }[e.key.toLowerCase()] : {
          arrowup: () => moveKb(true),
          arrowdown: () => moveKb(false),
          enter: () => batchOn ? openPicked() : commentOnHighlighted(),
          // In a batch, Space adds or removes the outlined element: after ↑ that is the parent, which a click would miss.
          ...batchOn ? { " ": () => {
            const t2 = currentTarget();
            if (t2) {
              const r = frozen ? t2.rect : rectOf(t2.el);
              togglePick(frozen ? { ...t2, fixed: true } : t2, r.left, r.bottom);
            }
          } } : {},
          a: () => !frozen && setArea(!areaMode),
          b: () => batchOn ? leaveBatch() : setBatch(true),
          f: () => frozen ? unfreeze() : freeze(),
          d: () => setDetails(!detailsOn),
          c: async () => toast(await copyComments().catch((err) => "Could not copy (" + err.message + ")"), 2500),
          s: () => {
            openArc();
            if (e.shiftKey) askName(true);
            else shareBtn.click();
          },
          l: toggleList,
          "?": () => {
            keysCard.hidden = !keysCard.hidden;
          }
        }[e.key.toLowerCase()];
        if (!run) return;
        e.preventDefault();
        e.stopPropagation();
        return void run();
      }
      if (asking) closeAsk();
      else if (meRow.classList.contains("editing")) drawMe();
      else if (!keysCard.hidden) keysCard.hidden = true;
      else if (menuState) closeMenu();
      else if (draft) closePop();
      else if (confirming) {
        confirming = false;
        drawPicked();
      } else if (areaMode) setArea(false);
      else if (batchOn) leaveBatch();
      else if (frozen) unfreeze();
      else if (commenting) setCommenting(false);
    };
    let picked = [], pickAt = { x: 0, y: 0 }, confirming = false, batchOn = false;
    const syncLayer = () => {
      areaLayer.hidden = !(areaMode && !frozen);
    };
    const setBatch = (on) => {
      batchOn = on;
      if (areaMode) setArea(false);
      if (on) {
        if (!commenting) setCommenting(true);
        closePop();
      }
      batchBtn.classList.toggle("active", on);
      main.firstChild.replaceWith(icon(on ? "batch" : areaMode ? "area" : commenting ? "comment" : "browse"));
      syncLayer();
      drawPicked();
    };
    const leaveBatch = () => picked.length ? askDrop() : setBatch(false);
    const pickRect = (t) => {
      if (t.fixed) return t.rect;
      const r = rectOf(t.el);
      if (!t.box) return r;
      const left = r.left + t.box.dx, top = r.top + t.box.dy;
      return { left, top, width: t.box.w, height: t.box.h, right: left + t.box.w, bottom: top + t.box.h };
    };
    const drawPicked = () => {
      pickedBoxes.replaceChildren(...picked.map((t) => {
        const r = pickRect(t);
        const x = h("button", { className: "x", title: "Remove from the selection", ariaLabel: "Remove from the selection" }, icon("close"));
        x.onclick = () => {
          picked.splice(picked.indexOf(t), 1);
          confirming = false;
          drawPicked();
        };
        return h("div", { className: "picked", style: `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px` }, x);
      }));
      if (!picked.length) confirming = false;
      pickBar.hidden = !batchOn;
      pickCount.textContent = confirming ? `Drop the ${picked.length} selected?` : `Batch \xB7 ${picked.length} selected \xB7 ${areaMode ? "drag to add an area (A: back to elements)" : "click or Space to add or remove, \u2191 for the parent (A: areas)"}`;
      pickComment.textContent = confirming ? "Keep" : "Comment";
      pickComment.disabled = !confirming && !picked.length;
      pickClear.textContent = confirming ? "Drop" : picked.length ? "Close without saving" : "Close";
    };
    const askDrop = () => {
      confirming = true;
      drawPicked();
    };
    const togglePick = (t, x, y) => {
      if (!batchOn) setBatch(true);
      const i = t.box ? -1 : picked.findIndex((p) => !p.box && p.el === t.el);
      if (i >= 0) picked.splice(i, 1);
      else picked.push(t);
      pickAt = { x, y };
      confirming = false;
      drawPicked();
    };
    const openPicked = () => {
      const list2 = picked;
      if (!list2.length) return;
      picked = [];
      setBatch(false);
      const one = list2[0];
      if (list2.length === 1 && !one.box) return openPop({ el: one.el, selector: one.selector, ...frozen ? { frozen: one } : {} }, pickAt.x, pickAt.y);
      if (list2.length === 1) return openPop({ el: one.el, selector: one.selector, ...frozen ? { frozen: one.entry } : {}, area: one.box, items: one.items }, pickAt.x, pickAt.y);
      let a = list2[0].el;
      for (const t of list2) while (a && !holds(a, t.el)) a = up(a);
      if (frozen) while (a && !frozen.byEl.has(a)) a = a.parentElement;
      const anchor = frozen ? a ? frozen.byEl.get(a) : frozen.entries[0] : liveTarget(a || document.body);
      const rects = list2.map(pickRect), ar = frozen ? anchor.rect : rectOf(anchor.el);
      const u = { left: Math.min(...rects.map((r) => r.left)), top: Math.min(...rects.map((r) => r.top)), right: Math.max(...rects.map((r) => r.right)), bottom: Math.max(...rects.map((r) => r.bottom)) };
      openPop({
        el: anchor.el,
        selector: anchor.selector,
        ...frozen ? { frozen: anchor } : {},
        group: true,
        area: { dx: Math.round(u.left - ar.left), dy: Math.round(u.top - ar.top), w: Math.round(u.right - u.left), h: Math.round(u.bottom - u.top) },
        items: list2.map((t) => t.box ? { selector: t.selector, box: t.box, text: clip(`area ${t.box.w}\xD7${t.box.h} over: ${t.items.map((it) => it.text).join(" | ")}`, 160) } : { selector: t.selector, text: clip(textOf(t.el), 80) }),
        picks: list2
      }, u.left, u.bottom);
    };
    pickComment.onclick = () => confirming ? (confirming = false, drawPicked()) : openPicked();
    pickClear.onclick = () => confirming ? (picked = [], setBatch(false)) : leaveBatch();
    batchBtn.onclick = () => batchOn ? leaveBatch() : setBatch(true);
    areaLayer.addEventListener("pointermove", (e) => {
      if (!batchOn || areaLayer.onpointerup) return;
      const el = document.elementsFromPoint(e.clientX, e.clientY).find((x) => x !== host && !host.contains(x));
      if (!el || kbTarget && kbTarget.el.contains(el)) return;
      kbTarget = null;
      kbStack = [];
      hovered = el;
      showHighlight(el.getBoundingClientRect(), inspect(el));
    });
    const onDown = (e) => {
      if (commenting && e.shiftKey && !ours(e)) e.preventDefault();
    };
    let hovered = null, kbTarget = null, kbStack = [];
    const currentTarget = () => kbTarget || (frozen ? hoveredEntry : hovered && hovered.isConnected ? liveTarget(hovered) : null);
    const moveKb = (up2) => {
      const t = currentTarget();
      if (!t) return;
      const next = up2 ? parentTarget(t) : kbStack.pop();
      if (!next) return;
      if (up2) kbStack.push(t);
      kbTarget = next;
      showHighlight(frozen ? next.rect : rectOf(next.el), next.info);
    };
    const commentOnHighlighted = () => {
      const t = currentTarget();
      if (!t) return;
      const r = frozen ? t.rect : rectOf(t.el);
      openPop({ el: t.el, selector: t.selector, ...frozen ? { frozen: t } : {} }, r.left, r.bottom);
    };
    const showAreaBox = (r) => {
      Object.assign(areaBox.style, { left: r.left + "px", top: r.top + "px", width: r.width + "px", height: r.height + "px" });
      areaBox.hidden = false;
    };
    const insideArea = (r) => {
      const found = [];
      for (const el of document.body.querySelectorAll("*")) {
        const b = el.getBoundingClientRect();
        if (!b.width || !b.height) continue;
        const ix = Math.min(b.right, r.right) - Math.max(b.left, r.left), iy = Math.min(b.bottom, r.bottom) - Math.max(b.top, r.top);
        if (ix > 0 && iy > 0 && ix * iy >= 0.6 * b.width * b.height) found.push(el);
      }
      const tops = found.filter((el) => !found.some((o) => o !== el && o.contains(el)));
      let anchor = tops[0] || document.elementsFromPoint((r.left + r.right) / 2, (r.top + r.bottom) / 2).find((e) => e !== host && !host.contains(e));
      for (const el of tops) while (anchor && !anchor.contains(el)) anchor = anchor.parentElement;
      return { anchor: anchor || document.body, tops };
    };
    const scrollsBy = (el, dx, dy) => {
      const st = getComputedStyle(el), can = (o) => /auto|scroll|overlay/.test(o);
      return dy && can(st.overflowY) && (dy > 0 ? el.scrollTop + el.clientHeight < el.scrollHeight - 1 : el.scrollTop > 0) || dx && can(st.overflowX) && (dx > 0 ? el.scrollLeft + el.clientWidth < el.scrollWidth - 1 : el.scrollLeft > 0);
    };
    areaLayer.addEventListener("wheel", (e) => {
      const k = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? innerHeight : 1, dx = e.deltaX * k, dy = e.deltaY * k;
      let el = document.elementsFromPoint(e.clientX, e.clientY).find((x) => x !== host && !host.contains(x));
      for (; el && el !== document.body && el !== document.documentElement; el = el.parentElement) {
        if (scrollsBy(el, dx, dy)) {
          e.preventDefault();
          return void el.scrollBy(dx, dy);
        }
      }
    }, { passive: false });
    areaLayer.onpointerdown = (e) => {
      e.preventDefault();
      if (unsaved()) return textarea.focus();
      closePop();
      const sx = e.clientX, sy = e.clientY;
      const rectTo = (m) => ({ left: Math.min(sx, m.clientX), top: Math.min(sy, m.clientY), width: Math.abs(m.clientX - sx), height: Math.abs(m.clientY - sy) });
      areaLayer.setPointerCapture(e.pointerId);
      areaLayer.onpointermove = (m) => showAreaBox(rectTo(m));
      areaLayer.onpointerup = (m) => {
        areaLayer.onpointermove = areaLayer.onpointerup = null;
        const r = rectTo(m);
        if (r.width < 8 || r.height < 8) {
          areaBox.hidden = true;
          const el = batchOn && document.elementsFromPoint(sx, sy).find((x) => x !== host && !host.contains(x));
          if (el) togglePick(kbTarget && kbTarget.el.contains(el) ? kbTarget : liveTarget(el), sx, sy);
          return;
        }
        const right = r.left + r.width, bottom = r.top + r.height;
        const { anchor, tops } = insideArea({ left: r.left, top: r.top, right, bottom });
        const a = anchor.getBoundingClientRect();
        const box2 = { dx: Math.round(r.left - a.left), dy: Math.round(r.top - a.top), w: Math.round(r.width), h: Math.round(r.height) };
        const items2 = tops.slice(0, 12).map((el) => ({ selector: selectorOf(el), text: clip(textOf(el), 80) }));
        if (batchOn) {
          areaBox.hidden = true;
          return togglePick({ el: anchor, selector: selectorOf(anchor), box: box2, items: items2 }, r.left, bottom);
        }
        openPop({ el: anchor, selector: selectorOf(anchor), area: box2, items: items2 }, r.left, bottom);
      };
    };
    const liveTarget = (el) => ({ el, rect: rectOf(el), info: inspect(el), selector: selectorOf(el) });
    const overlap60 = (b, r) => {
      const ix = Math.min(b.right, r.right) - Math.max(b.left, r.left), iy = Math.min(b.bottom, r.bottom) - Math.max(b.top, r.top);
      return ix > 0 && iy > 0 && ix * iy >= 0.6 * b.width * b.height;
    };
    let frozen = null;
    const record = () => {
      const entries = [], byEl2 = /* @__PURE__ */ new Map(), seen = /* @__PURE__ */ new Map();
      for (const el of document.body.querySelectorAll("*")) {
        const r = el.getBoundingClientRect();
        if (!r.width || !r.height || r.bottom < 0 || r.right < 0 || r.top > innerHeight || r.left > innerWidth) continue;
        const top = document.elementFromPoint(Math.min(innerWidth - 1, Math.max(0, (r.left + r.right) / 2)), Math.min(innerHeight - 1, Math.max(0, (r.top + r.bottom) / 2)));
        const entry = {
          el,
          rect: { left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height },
          selector: selectorOf(el),
          info: inspect(el, seen),
          covered: !(top && (top === el || el.contains(top)))
        };
        entries.push(entry);
        byEl2.set(el, entry);
        if (entries.length >= 4e3) break;
      }
      return { entries, byEl: byEl2 };
    };
    const frozenAt = (x, y) => {
      let best = null;
      for (const en of frozen.entries) {
        const r = en.rect;
        if (x < r.left || x > r.right || y < r.top || y > r.bottom) continue;
        if (!best || best.covered && !en.covered || best.covered === en.covered && r.width * r.height <= best.rect.width * best.rect.height) best = en;
      }
      return best;
    };
    const freeze = async () => {
      if (frozen) return;
      closeMenu();
      if (unsaved()) return textarea.focus();
      closePop();
      if (!platform.capture.ready()) return freezeLater();
      host.style.visibility = "hidden";
      try {
        const { entries, byEl: byEl2 } = record();
        await new Promise(requestAnimationFrame);
        const { source, k } = await platform.capture.grab();
        const canvas = h("canvas", { width: source.videoWidth || source.width, height: source.videoHeight || source.height });
        canvas.getContext("2d").drawImage(source, 0, 0);
        frozen = { canvas, k, entries, byEl: byEl2 };
      } catch (err) {
        return toast("Could not freeze: " + err.message);
      } finally {
        host.style.visibility = "";
      }
      freezeLayer.replaceChildren(frozen.canvas, freezeLayer.lastChild);
      freezeLayer.hidden = false;
      syncLayer();
      freezeBtn.classList.add("active");
      freezeBtn.baseLabel = freezeBtn.labelEl.textContent = "Unfreeze";
      if (!commenting) setCommenting(true);
    };
    const unfreeze = () => {
      if (!frozen) return;
      picked = picked.filter((t) => !t.fixed);
      kbTarget = hoveredEntry = null;
      kbStack = [];
      frozen = null;
      drawPicked();
      freezeLayer.hidden = true;
      syncLayer();
      freezeBtn.classList.remove("active");
      freezeBtn.baseLabel = freezeBtn.labelEl.textContent = FREEZE_LABEL;
      closeMenu();
      if (!unsaved()) closePop();
      hl.hidden = true;
    };
    unfreezeBtn.onclick = (e) => {
      e.stopPropagation();
      unfreeze();
    };
    let countdown = 0;
    const freezeLater = async () => {
      if (countdown) return;
      if (unsaved()) return textarea.focus();
      if (!platform.capture.ready()) {
        try {
          await platform.capture.start();
        } catch (err) {
          return toast("Freeze needs screen sharing: " + (err.name === "NotAllowedError" ? "it was not allowed." : err.message));
        }
      }
      if (countdown || frozen || unsaved()) return;
      setCommenting(false);
      let left = 3;
      toast(`Freezing in ${left}\u2026 open the menu or hover the tooltip now`, 1100);
      countdown = setInterval(() => {
        if (--left > 0) return toast(`Freezing in ${left}\u2026`, 1100);
        clearInterval(countdown);
        countdown = 0;
        freeze();
      }, 1e3);
    };
    freezeBtn.onclick = () => frozen ? unfreeze() : freezeLater();
    let hoveredEntry = null;
    freezeLayer.onpointermove = (e) => {
      if (draft || menuState || e.target !== freezeLayer.firstChild) return;
      const en = frozenAt(e.clientX, e.clientY);
      if (kbTarget && en && kbTarget.el.contains(en.el)) return;
      kbTarget = null;
      kbStack = [];
      hoveredEntry = en;
      if (en) showHighlight(en.rect, en.info);
      else hl.hidden = true;
    };
    freezeLayer.onpointerdown = (e) => {
      if (e.button !== 0 || e.target !== freezeLayer.firstChild) return;
      e.preventDefault();
      if (menuState) return closeMenu();
      if (unsaved()) return textarea.focus();
      if (!panel.hidden || draft) {
        panel.hidden = true;
        closePop();
        return freezeLayer.onpointermove(e);
      }
      const sx = e.clientX, sy = e.clientY;
      const rectTo = (m) => ({ left: Math.min(sx, m.clientX), top: Math.min(sy, m.clientY), width: Math.abs(m.clientX - sx), height: Math.abs(m.clientY - sy) });
      freezeLayer.setPointerCapture(e.pointerId);
      freezeLayer.onpointerup = (m) => {
        freezeLayer.onpointerup = null;
        const r = rectTo(m);
        if (r.width < 8 || r.height < 8) {
          areaBox.hidden = true;
          const at = frozenAt(sx, sy), en = kbTarget && at && kbTarget.el.contains(at.el) ? kbTarget : at;
          if (batchOn || m.shiftKey) return en && togglePick({ ...en, fixed: true }, sx, sy);
          if (en) openPop({ el: en.el, selector: en.selector, frozen: en }, sx, sy);
          return;
        }
        const box2 = { left: r.left, top: r.top, right: r.left + r.width, bottom: r.top + r.height };
        const found = frozen.entries.filter((en) => !en.covered && overlap60(en.rect, box2));
        const tops = found.filter((en) => !found.some((o) => o !== en && o.el.contains(en.el)));
        let anchorEl = tops[0]?.el || frozenAt((box2.left + box2.right) / 2, (box2.top + box2.bottom) / 2)?.el;
        for (const t of tops) while (anchorEl && !anchorEl.contains(t.el)) anchorEl = anchorEl.parentElement;
        while (anchorEl && !frozen.byEl.has(anchorEl)) anchorEl = anchorEl.parentElement;
        const anchor = anchorEl ? frozen.byEl.get(anchorEl) : frozen.entries[0];
        const area = { dx: Math.round(r.left - anchor.rect.left), dy: Math.round(r.top - anchor.rect.top), w: Math.round(r.width), h: Math.round(r.height) };
        const items2 = tops.slice(0, 12).map((en) => ({ selector: en.selector, text: clip(textOf(en.el), 80) }));
        if (batchOn || m.shiftKey) {
          areaBox.hidden = true;
          return togglePick({ el: anchor.el, selector: anchor.selector, entry: anchor, fixed: true, rect: { ...box2, width: r.width, height: r.height }, box: area, items: items2 }, r.left, box2.bottom);
        }
        openPop({ el: anchor.el, selector: anchor.selector, frozen: anchor, area, items: items2 }, r.left, box2.bottom);
      };
      const onDrag = (m) => showAreaBox(rectTo(m));
      freezeLayer.addEventListener("pointermove", onDrag);
      freezeLayer.addEventListener("pointerup", () => freezeLayer.removeEventListener("pointermove", onDrag), { once: true });
    };
    freezeLayer.oncontextmenu = (e) => {
      e.preventDefault();
      const en = frozenAt(e.clientX, e.clientY);
      if (en) openMenu(en, e.clientX, e.clientY);
    };
    let menuState = null;
    const parentTarget = (t) => {
      if (frozen) {
        for (let e = t.el.parentElement; e; e = e.parentElement) if (frozen.byEl.has(e)) return frozen.byEl.get(e);
        return null;
      }
      const p = up(t.el);
      return p ? liveTarget(p) : null;
    };
    const menuItem = (label, hint, run) => h(
      "button",
      { className: "mi", onclick: (e) => {
        e.stopPropagation();
        run();
      } },
      h("span", { textContent: label }),
      h("span", { className: "mk", textContent: hint })
    );
    const renderMenu = () => {
      const { target: t, stack, x, y } = menuState, up2 = parentTarget(t);
      showHighlight(t.rect, t.info);
      menu.replaceChildren(...[
        h("div", { className: "mh" }, h("span", { className: "t", textContent: t.info.label }), t.info.size.replace("\xD7", " \xD7 ")),
        menuItem("Comment on this", "Enter", () => {
          closeMenu();
          openPop({ el: t.el, selector: t.selector, ...frozen ? { frozen: t } : {} }, x, y);
        }),
        up2 && menuItem("Select parent", "\u2191 " + up2.info.label, () => {
          menuState = { ...menuState, target: up2, stack: [...stack, t] };
          renderMenu();
        }),
        stack.length && menuItem("Select inner", "\u2193 " + stack.at(-1).info.label, () => {
          menuState = { ...menuState, target: stack.at(-1), stack: stack.slice(0, -1) };
          renderMenu();
        }),
        h("hr"),
        !frozen && menuItem("Select an area", "A", () => {
          closeMenu();
          setArea(true);
        }),
        menuItem("Select several (batch)", "B", () => {
          closeMenu();
          setBatch(true);
        }),
        menuItem(frozen ? "Unfreeze" : "Freeze the page", "F", () => {
          closeMenu();
          frozen ? unfreeze() : freeze();
        }),
        menuItem("Keyboard shortcuts", "?", () => {
          closeMenu();
          keysCard.hidden = false;
        }),
        menuItem("Copy selector", "", async () => {
          closeMenu();
          try {
            await writeClipboard({ text: t.selector });
            toast("Copied " + t.selector, 2e3);
          } catch (err) {
            toast("Could not copy (" + err.message + ")");
          }
        })
      ].filter(Boolean));
      menu.style.left = Math.max(8, Math.min(x, innerWidth - menu.offsetWidth - 8)) + "px";
      menu.style.top = Math.max(8, Math.min(y, innerHeight - menu.offsetHeight - 8)) + "px";
    };
    const openMenu = (target, x, y) => {
      if (unsaved()) return textarea.focus();
      closePop();
      menuState = { target, stack: [], x, y };
      menu.hidden = false;
      renderMenu();
    };
    const closeMenu = () => {
      if (!menuState) return;
      menuState = null;
      menu.hidden = true;
      hl.hidden = true;
    };
    const onContext = (e) => {
      if (!commenting || frozen || ours(e)) return;
      e.preventDefault();
      e.stopPropagation();
      const { x, y } = pointOf(e);
      openMenu(liveTarget(e.target), x, y);
    };
    addEventListener("contextmenu", onContext, true);
    addEventListener("mousedown", onDown, true);
    addEventListener("mousemove", onMove, true);
    addEventListener("click", onClick, true);
    addEventListener("keydown", onKey, true);
    addEventListener("scroll", schedulePlace, true);
    const onScrollMenu = (e) => {
      if (!ours(e)) closeMenu();
    };
    addEventListener("scroll", onScrollMenu, true);
    addEventListener("resize", schedulePlace);
    addEventListener("resize", refitPop);
    const linked = /* @__PURE__ */ new Map();
    const ownTool = (doc) => doc.documentElement?.dataset.pageComments !== void 0;
    const FRAME_EVENTS = [
      ["mousemove", onMove],
      ["click", onClick],
      ["mousedown", onDown],
      ["contextmenu", onContext],
      ["keydown", onKey],
      ["scroll", schedulePlace],
      ["scroll", onScrollMenu],
      ["resize", schedulePlace]
    ];
    const onFrameLoad = (e) => {
      if (e.target.matches?.(FRAMES)) {
        linkFrame(e.target);
        schedulePlace();
      }
    };
    const linkFrame = (f) => {
      for (const [doc2, undo] of linked) if (!doc2.defaultView) undo();
      const doc = f.contentDocument;
      if (!doc?.documentElement || ownTool(doc)) return f.removeAttribute(LINKED);
      f.setAttribute(LINKED, "");
      if (linked.has(doc)) return;
      const win = doc.defaultView, sheet2 = new win.CSSStyleSheet();
      sheet2.replaceSync(embedRule);
      const handlers = FRAME_EVENTS.map(([type, fn]) => [type, (e) => ownTool(doc) || fn(e)]);
      for (const [type, fn] of handlers) win.addEventListener(type, fn, true);
      doc.addEventListener("load", onFrameLoad, true);
      sheets.set(doc, sheet2);
      linked.set(doc, () => {
        try {
          for (const [type, fn] of handlers) win.removeEventListener(type, fn, true);
        } catch {
        }
        doc.removeEventListener("load", onFrameLoad, true);
        doc.adoptedStyleSheets = doc.adoptedStyleSheets.filter((x) => x !== sheet2);
        sheets.delete(doc);
        linked.delete(doc);
      });
      passEmbeds(commenting);
      doc.querySelectorAll(FRAMES).forEach(linkFrame);
    };
    document.addEventListener("load", onFrameLoad, true);
    document.querySelectorAll(FRAMES).forEach(linkFrame);
    const POS_KEY = "page-comments:pos";
    let pos = null;
    try {
      pos = JSON.parse(localStorage.getItem(POS_KEY));
    } catch {
    }
    if (!Number.isFinite(pos?.x) || !Number.isFinite(pos?.y)) pos = null;
    const centre = () => {
      if (dodge) return dodge;
      const x = pos ? pos.x : innerWidth - 66, y = pos ? pos.y : innerHeight - 66;
      return { x: Math.max(66, Math.min(innerWidth - 66, x)), y: Math.max(66, Math.min(innerHeight - 66, y)) };
    };
    const layoutBar = () => {
      const { x, y } = centre();
      widget.classList.toggle("left", x < innerWidth / 2);
      widget.classList.toggle("top", y < innerHeight / 2);
    };
    const placeDock = () => {
      const { x, y } = centre(), d = dock.getBoundingClientRect();
      const onRight = x > innerWidth / 2, onTop = y < innerHeight / 2;
      dock.style.flexDirection = onTop ? "column-reverse" : "column";
      dock.style.alignItems = onRight ? "flex-end" : "flex-start";
      const left = onRight ? x + 26 - d.width : x - 26, top = onTop ? y + 64 : y - 64 - d.height;
      dock.style.left = Math.max(8, Math.min(innerWidth - d.width - 8, left)) + "px";
      dock.style.top = Math.max(8, Math.min(innerHeight - d.height - 8, top)) + "px";
    };
    const clearTip = (on) => {
      dock.style.translate = "";
      const d = dock.getBoundingClientRect();
      if (!on || !d.height) return;
      const t = mainTip.getBoundingClientRect(), below = d.top > t.top;
      const by = below ? t.bottom + 8 - d.top : d.bottom - (t.top - 8);
      if (by > 0) dock.style.translate = `0 ${below ? by : -by}px`;
    };
    main.addEventListener("mouseenter", () => clearTip(true));
    main.addEventListener("mouseleave", () => clearTip(false));
    const placeWidget = () => {
      const { x, y } = centre();
      widget.style.left = x + "px";
      widget.style.top = y + "px";
      layoutBar();
      placeDock();
    };
    const dodgeBox = () => {
      const p = pop.getBoundingClientRect(), m = 26 + 12;
      const hits = (c) => c.x + m > p.left && c.x - m < p.right && c.y + m > p.top && c.y - m < p.bottom;
      const was = dodge;
      dodge = null;
      const home = centre();
      if (!hits(home)) {
        if (was) placeWidget();
        return;
      }
      const corners = [[innerWidth - 66, innerHeight - 66], [66, innerHeight - 66], [innerWidth - 66, 66], [66, 66]].map(([x, y]) => ({ x, y }));
      dodge = corners.filter((c) => !hits(c)).sort((a, b) => Math.hypot(a.x - home.x, a.y - home.y) - Math.hypot(b.x - home.x, b.y - home.y))[0] || null;
      placeWidget();
    };
    const dockObserver = new ResizeObserver(placeDock);
    dockObserver.observe(dock);
    addEventListener("resize", placeWidget);
    let closeTimer = 0;
    const openArc = () => {
      clearTimeout(closeTimer);
      if (!widget.classList.contains("open")) {
        layoutBar();
        if (pageIsLocal && Date.now() - lastCheck > 1e4) checkServer();
      }
      widget.classList.add("open");
    };
    const closeArc = () => {
      clearTimeout(closeTimer);
      closeTimer = setTimeout(() => {
        if (asking) return;
        widget.classList.remove("open", "listopen");
        moreBtn.classList.remove("on");
      }, 1200);
    };
    const closeMore = () => {
      widget.classList.remove("listopen");
      moreBtn.classList.remove("on");
    };
    moreBtn.onclick = () => {
      closeAsk();
      const on = widget.classList.toggle("listopen");
      moreBtn.classList.toggle("on", on);
      if (on) panel.hidden = true;
    };
    const toggleList = () => {
      panel.hidden = !panel.hidden;
      if (!panel.hidden) closeMore();
    };
    detailsAct.onclick = () => {
      setDetails(!detailsOn);
      closeMore();
    };
    keysAct.onclick = () => {
      keysCard.hidden = !keysCard.hidden;
      closeMore();
    };
    main.addEventListener("mouseenter", openArc);
    widget.addEventListener("mouseover", openArc);
    widget.addEventListener("mouseleave", closeArc);
    widget.addEventListener("focusin", openArc);
    widget.addEventListener("focusout", closeArc);
    main.onpointerdown = (e) => {
      e.preventDefault();
      const sx = e.clientX, sy = e.clientY, start2 = centre();
      dodge = null;
      let moved = false;
      main.setPointerCapture(e.pointerId);
      main.onpointermove = (m) => {
        if (!moved && Math.hypot(m.clientX - sx, m.clientY - sy) < 4) return;
        moved = true;
        main.classList.add("dragging");
        widget.classList.remove("open");
        pos = { x: start2.x + m.clientX - sx, y: start2.y + m.clientY - sy };
        placeWidget();
      };
      main.onpointerup = main.onpointercancel = () => {
        main.onpointermove = main.onpointerup = main.onpointercancel = null;
        main.classList.remove("dragging");
        if (!moved) return setCommenting(!commenting);
        try {
          localStorage.setItem(POS_KEY, JSON.stringify(centre()));
        } catch {
        }
        openArc();
      };
    };
    main.onkeydown = (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        setCommenting(!commenting);
      }
    };
    const onStorage = (e) => {
      if (e.key !== KEY) return;
      comments = load();
      if (!unsaved()) closePop();
      else if (draft.comment) draft.comment = comments.find((x) => x.id === draft.comment.id) || draft.comment;
      render();
    };
    addEventListener("storage", onStorage);
    const urlTimer = setInterval(() => {
      if (pageOf() === page || unsaved()) return;
      page = pageOf();
      closePop();
      render();
    }, 300);
    textarea.oninput = () => {
      saveBtn.disabled = !textarea.value.trim();
    };
    shotBox.onchange = () => {
      if (draft && !draft.comment && !draft.area && !draft.frozen) try {
        localStorage.setItem(SHOT_KEY, shotBox.checked ? "1" : "0");
      } catch {
      }
    };
    textarea.onkeydown = (e) => {
      if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        save();
      }
    };
    for (const type of ["keydown", "keyup", "keypress"]) textarea.addEventListener(type, (e) => e.stopPropagation());
    listBtn.onclick = toggleList;
    areaBtn.onclick = () => setArea(!areaMode);
    const flash = (act, text, ms = 2500) => {
      clearTimeout(act.flashTimer);
      act.labelEl.textContent = text;
      act.classList.add("flash");
      layoutBar();
      act.flashTimer = setTimeout(() => {
        act.labelEl.textContent = act.baseLabel;
        act.classList.remove("flash");
        layoutBar();
      }, ms);
    };
    const disarmClear = () => {
      clearTimeout(clearTimer);
      clearBtn.classList.remove("armed");
      clearBtn.labelEl.textContent = "Clear all";
      layoutBar();
    };
    clearBtn.onclick = () => {
      if (!clearBtn.classList.contains("armed")) {
        clearBtn.classList.add("armed");
        clearBtn.labelEl.textContent = "Click again to clear " + here().length;
        layoutBar();
        clearTimer = setTimeout(disarmClear, 3e3);
        return;
      }
      disarmClear();
      const mine = new Set(here());
      for (const c of mine) if (c.shot) dropShot(c.id);
      comments = comments.filter((c) => !mine.has(c));
      closePop();
      render();
      flash(clearBtn, "Cleared");
    };
    saveBtn.onclick = save;
    cancelBtn.onclick = closePop;
    deleteBtn.onclick = () => remove(draft.comment);
    boxCopyBtn.onclick = async () => {
      const d = draft, text = textarea.value.trim();
      if (!d) return;
      const el = d.el || d.comment && elOf(d.comment);
      const c = d.comment ? { ...d.comment, comment: text || d.comment.comment } : commentFrom({ ...d, el }, text || "(no comment yet)");
      const found = /* @__PURE__ */ new Map();
      try {
        if (shotBox.checked && el) {
          const tmp = { ...c, id: "copy-" + newId() };
          await takePictures(tmp, { el, picks: d.picks, rec: d.frozen, area: d.area });
          const v = await shots("readonly", (st) => st.get(tmp.id));
          dropShot(tmp.id);
          Object.assign(c, { shot: true, shotCount: tmp.shotCount, shotWidth: tmp.shotWidth });
          found.set(c, Array.isArray(v) ? v : [{ blob: v, width: tmp.shotWidth }]);
        }
        await copyItems([{ c, n: 1 }], found);
        toast(`Copied this comment${found.size ? " with its picture" : ""}, not saved.`, 2500);
      } catch (err) {
        toast("Could not copy (" + (err.name === "NotAllowedError" ? "sharing this tab was not allowed" : err.message) + ")");
      }
      textarea.focus();
    };
    const copyComments = async (only, textOnly) => copyItems(numbered(only), textOnly ? /* @__PURE__ */ new Map() : await pageShots());
    const copyItems = async (items2, found) => {
      const text = toText(items2);
      const html2 = await toHtml(items2, found);
      const withPics = items2.filter((x) => found.get(x.c));
      await writeClipboard({ text, html: html2, png: withPics.length && navigator.clipboard ? await contactSheet(withPics, found) : null });
      return `Copied ${items2.length}${withPics.length ? " + screenshots" : ""}`;
    };
    textBtn.onclick = async () => {
      try {
        toast(await copyComments(null, true) + ": paste it, then Copy pictures for the second paste.", 3e3);
      } catch (err) {
        toast("Could not copy (" + err.message + ")");
      }
    };
    const SHARE_KEY = "page-comments=", LINK_MAX = 7500;
    const WHO = ["#7c3aed", "#0891b2", "#16a34a", "#db2777", "#475569", "#0d9488", "#c026d3", "#65a30d", "#be123c", "#854d0e"];
    const colourOf = (name) => {
      if (!name) return WHO[0];
      let n = 0;
      for (const ch of name.toLowerCase()) n = n * 31 + ch.codePointAt(0) >>> 0;
      return WHO[n % WHO.length];
    };
    const smallPic = async ({ blob, width }) => {
      const bmp = await createImageBitmap(blob), k = width ? Math.min(1, width / bmp.width) : 1;
      const canvas = h("canvas", { width: Math.round(bmp.width * k), height: Math.round(bmp.height * k) });
      canvas.getContext("2d").drawImage(bmp, 0, 0, canvas.width, canvas.height);
      return { url: await dataUrl(await new Promise((ok) => canvas.toBlob(ok, "image/webp", 0.7))), width: canvas.width };
    };
    const blobOf = (url) => {
      const [head, b64] = url.split(",");
      return new Blob([Uint8Array.from(atob(b64), (ch) => ch.charCodeAt(0))], { type: head.slice(5, -7) });
    };
    const bytesOf = async (stream) => new Uint8Array(await new Response(stream).arrayBuffer());
    const pack = async (data) => {
      let bin = "";
      for (const b of await bytesOf(new Blob([JSON.stringify(data)]).stream().pipeThrough(new CompressionStream("deflate-raw")))) bin += String.fromCharCode(b);
      return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    };
    const unpack = async (str) => {
      const bytes = Uint8Array.from(atob(str.replace(/-/g, "+").replace(/_/g, "/")), (ch) => ch.charCodeAt(0));
      return JSON.parse(new TextDecoder().decode(await bytesOf(new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw")))));
    };
    let missingPics = [];
    const retakeText = h("span"), retakeBtn = h("button", { textContent: "Retake" }), skipBtn = h("button", { textContent: "Skip" });
    const retakeBar = h("div", { className: "freeze-bar pick-bar", hidden: true }, retakeText, retakeBtn, skipBtn);
    root.append(retakeBar);
    const drawRetake = () => {
      retakeBar.hidden = !missingPics.length;
      retakeText.textContent = `${missingPics.length} shared comment(s) came without their pictures \xB7 take them on this page?`;
    };
    skipBtn.onclick = () => {
      missingPics = [];
      drawRetake();
    };
    retakeBtn.onclick = async () => {
      const list2 = missingPics;
      missingPics = [];
      drawRetake();
      let done = 0, skipped = 0;
      for (const c of list2) {
        const el = elOf(c);
        if (!el || c.frozen) {
          skipped++;
          continue;
        }
        try {
          await takePictures(c, { el });
          done++;
        } catch (err) {
          if (err.name === "NotAllowedError") {
            toast("No pictures: sharing this tab was not allowed.");
            break;
          }
          skipped++;
        }
      }
      render();
      toast(`Took ${done} picture(s) on this page` + (skipped ? `; ${skipped} could not be taken (frozen, or not on this page).` : "."), 6e3);
    };
    const splitHash = () => {
      const hash = location.hash.slice(1), at = hash.indexOf(SHARE_KEY);
      return at < 0 ? { own: hash, ours: "" } : { own: hash.slice(0, at).replace(/&$/, ""), ours: hash.slice(at + SHARE_KEY.length) };
    };
    const importShared = async () => {
      const { own, ours: ours2 } = splitHash();
      if (!ours2) return;
      try {
        const data = await unpack(ours2);
        if (!Array.isArray(data)) throw new Error("newer");
        const have = new Set(comments.map((c) => c.id));
        const fresh = data.map((c) => fromLink(c, pageOf())).filter((c) => c && !have.has(c.id));
        for (const c of fresh) {
          const pics = c.pics;
          if (c.hadPic && !pics.length) missingPics.push(c);
          delete c.pics;
          delete c.hadPic;
          if (!pics.length) continue;
          try {
            if (pics.length > 1) {
              await putShot(c.id, pics.map((p) => ({ blob: blobOf(p.url), width: p.width })));
              c.shotCount = pics.length;
            } else {
              await putShot(c.id, blobOf(pics[0].url));
              c.shotWidth = pics[0].width;
            }
            c.shot = true;
          } catch {
          }
        }
        comments.push(...fresh);
        render();
        toast(fresh.length ? `Opened ${fresh.length} shared comment(s) on this page.` : "The shared comments are already here.");
        drawRetake();
      } catch (err) {
        toast(err.message === "newer" ? "This link was made by a newer version of page-comments: update yours, then open the link again." : "Could not read the comments in this link: it may have been cut short.");
      }
      if (own) location.replace("#" + own);
      else history.replaceState(history.state, "", location.href.split("#")[0]);
    };
    const NAME_KEY = "page-comments:name";
    const myName = () => {
      try {
        return localStorage.getItem(NAME_KEY) || "";
      } catch {
        return "";
      }
    };
    const setName = (name) => {
      try {
        localStorage.setItem(NAME_KEY, name);
      } catch {
      }
      try {
        platform.saveName?.(name);
      } catch {
      }
      drawMe();
    };
    platform.loadName?.().then((kept) => {
      if (kept && kept !== myName()) {
        try {
          localStorage.setItem(NAME_KEY, kept);
        } catch {
        }
        drawMe();
      } else if (!kept && myName()) platform.saveName(myName());
    }).catch(() => {
    });
    let asking = null;
    const closeAsk = () => {
      if (!asking) return;
      asking.remove();
      asking = null;
      shareBtn.classList.remove("held");
      if (!widget.matches(":hover")) closeArc();
    };
    const placeAsk = () => {
      if (!asking) return;
      const wr = widget.getBoundingClientRect(), sr = shareBtn.getBoundingClientRect(), cx = sr.left + sr.width / 2, w = asking.offsetWidth;
      const left = Math.min(Math.max(cx - w / 2, 8), innerWidth - 8 - w);
      asking.style.left = left - wr.left + "px";
      asking.style.setProperty("--ax", cx - left + "px");
    };
    const askName = (again) => {
      closeAsk();
      closeMore();
      openArc();
      const input = h("input", { placeholder: "Your name", maxLength: 40, dir: "auto", value: myName() });
      const form = h("form", {}, input, h("button", { type: "submit", textContent: "Share" }));
      asking = h(
        "div",
        { className: "ask" },
        h("span", { className: "t", textContent: again ? "Change your name on shared comments" : "Your name on shared comments" }),
        form,
        h("span", { className: "hint" }, KEPT + " ", h("kbd", { textContent: "Esc" }), " cancels")
      );
      form.onsubmit = (e) => {
        e.preventDefault();
        const name = input.value.trim();
        if (!name) return input.focus();
        setName(name);
        closeAsk();
        share();
      };
      for (const type of ["keydown", "keyup", "keypress"]) input.addEventListener(type, (e) => e.stopPropagation());
      shareBtn.classList.add("held");
      widget.append(asking);
      placeAsk();
      setTimeout(placeAsk, 400);
      input.focus({ preventScroll: true });
      input.select();
    };
    addEventListener("resize", placeAsk);
    const drawMe = (editing) => {
      meRow.classList.toggle("editing", !!editing);
      if (!editing) {
        const me = myName();
        return meRow.replaceChildren(icon("person"), h(
          "span",
          { className: "label" },
          h("span", { className: "who-am-i" }, "Your name: ", me ? h("b", { textContent: me }) : h("i", { textContent: "not set yet" })),
          h("span", { className: "chg", textContent: me ? "Change" : "Set" })
        ));
      }
      const input = h("input", { placeholder: "Your name", maxLength: 40, dir: "auto", value: myName() });
      const form = h("form", {}, input, h("button", { type: "submit", textContent: "Save" }));
      form.onsubmit = (e) => {
        e.preventDefault();
        const name = input.value.trim();
        if (!name) return input.focus();
        setName(name);
      };
      for (const type of ["keydown", "keyup", "keypress"]) input.addEventListener(type, (e) => {
        e.stopPropagation();
        if (type === "keydown" && e.key === "Escape") drawMe();
      });
      meRow.replaceChildren(icon("person"), form);
      input.focus({ preventScroll: true });
      input.select();
    };
    meRow.onclick = () => {
      if (!meRow.classList.contains("editing")) drawMe(true);
    };
    drawMe();
    shareBtn.onclick = () => asking ? closeAsk() : myName() ? share() : askName();
    const share = async () => {
      try {
        const me = myName();
        const found = await pageShots(), plain = (c) => ({ ...Object.fromEntries(SHARED.filter((k) => c[k] !== void 0).map((k) => [k, c[k]])), by: c.by || me || void 0 });
        const withPics = await Promise.all(here().map(async (c) => ({ ...plain(c), ...found.get(c) ? { pics: await Promise.all(found.get(c).map(smallPic)) } : {} })));
        const { own } = splitHash(), start2 = location.href.split("#")[0] + "#" + (own ? own + "&" : "") + SHARE_KEY;
        let link = start2 + await pack(withPics), note = found.size ? " with pictures" : "";
        if (link.length > LINK_MAX) {
          note = `, pictures left out (with them it would be ${(link.length / 1024).toFixed(0)} KB, too long for Slack)`;
          link = start2 + await pack(here().map((c) => ({ ...plain(c), ...found.get(c) ? { hadPic: true } : {} })));
        }
        if (link.length > LINK_MAX) note += ". It is still long: Slack may refuse it, so send it by email or as a file there";
        await writeClipboard({ text: link });
        const change = h("button", { className: "chg", textContent: "Change name", onclick: () => askName(true) });
        toast([
          `Copied a link with ${here().length} comment(s)${note}, ${(link.length / 1024).toFixed(1)} KB, as ${me} \xB7 `,
          change,
          ". Whoever opens it and clicks their bookmark sees them." + (pageIsLocal ? " This page is on your machine: only you can open it." : "")
        ], 7e3);
      } catch (err) {
        toast("Could not copy the link (" + err.message + ")");
      }
    };
    addEventListener("hashchange", importShared);
    const slug = (t) => clip(t, 40).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "comment";
    filesBtn.onclick = async () => {
      try {
        const found = await pageShots(), items2 = numbered().filter((x) => found.get(x.c));
        if (!items2.length) return toast("No pictures on this page yet: tick Add screenshot on a comment.");
        const files = [];
        for (const x of items2) {
          const pics = found.get(x.c);
          for (const [k, p] of pics.entries()) {
            files.push({ name: `${x.n}${tagOf(pics, k)}-${slug(x.c.comment)}.png`, bytes: new Uint8Array(await (await png(await captioned(x, p, tagOf(pics, k)))).arrayBuffer()) });
          }
        }
        toast(await platform.saveFiles(files, `page-comments-${slug(location.hostname)}-${files.length}-pictures.zip`), 7e3);
      } catch (err) {
        toast("Could not save the pictures (" + err.message + ")");
      }
    };
    picsBtn.onclick = async () => {
      try {
        const found = await pageShots(), items2 = numbered().filter((x) => found.get(x.c));
        if (!items2.length) return toast("No pictures on this page yet: tick Add screenshot on a comment.");
        await writeClipboard({ png: await contactSheet(items2, found) });
        toast("Copied the pictures: paste them as a second paste.", 3e3);
      } catch (err) {
        toast("Could not copy (" + err.message + ")");
      }
    };
    copyBtn.onclick = async () => {
      try {
        flash(copyBtn, await copyComments());
      } catch (err) {
        return flash(copyBtn, "Could not copy (" + err.message + ")", 5e3);
      }
      try {
        if (localStorage.getItem("page-comments:jira-tip") !== "1" && (await pageShots()).size) {
          localStorage.setItem("page-comments:jira-tip", "1");
          toast("Pasting into Jira or Confluence? They take text and pictures only in two pastes: open Comments, Copy text and paste, then Copy pictures and paste.", 9e3);
        }
      } catch {
      }
    };
    const pageIsLocal = /^(localhost|127(\.\d+){3}|\[::1\])$|\.(localhost|test|local|internal|home\.arpa)$/.test(location.hostname);
    let lastCheck = 0;
    const checkServer = async () => {
      lastCheck = Date.now();
      try {
        sendBtn.hidden = !pageIsLocal || !(await fetch(SERVER + "/health", { signal: AbortSignal.timeout(2e3) })).ok;
      } catch {
        sendBtn.hidden = true;
      }
      layoutBar();
    };
    sendBtn.onclick = async () => {
      flash(sendBtn, "Sending\u2026");
      try {
        const found = await pageShots();
        const images = await Promise.all(here().map((c) => found.get(c) ? Promise.all(found.get(c).map((p) => dataUrl(p.blob))) : null));
        const res = await fetch(SERVER + "/comments", { method: "POST", body: JSON.stringify({ text: toText(), images }) });
        flash(sendBtn, res.ok ? "Sent: Claude is working, see the server terminal" : "Server said: " + await res.text(), 5e3);
      } catch {
        flash(sendBtn, "Server not reachable: use Copy", 3e3);
        setTimeout(checkServer, 3e3);
      }
    };
    const destroy = () => {
      removeEventListener("mousemove", onMove, true);
      removeEventListener("click", onClick, true);
      removeEventListener("keydown", onKey, true);
      removeEventListener("contextmenu", onContext, true);
      removeEventListener("mousedown", onDown, true);
      removeEventListener("scroll", onScrollMenu, true);
      clearInterval(countdown);
      removeEventListener("scroll", schedulePlace, true);
      removeEventListener("resize", schedulePlace);
      removeEventListener("resize", refitPop);
      removeEventListener("resize", placeAsk);
      removeEventListener("resize", placeWidget);
      dockObserver.disconnect();
      clearTimeout(closeTimer);
      removeEventListener("storage", onStorage);
      removeEventListener("hashchange", importShared);
      cancelAnimationFrame(frame);
      clearTimeout(toastTimer);
      clearTimeout(clearTimer);
      clearInterval(urlTimer);
      platform.capture.stop();
      document.removeEventListener("page-comments:close", destroy);
      if (document.documentElement.dataset.pageComments === platform.name) delete document.documentElement.dataset.pageComments;
      passEmbeds(false);
      for (const doc of [document, ...linked.keys()]) for (const f of doc.querySelectorAll(`[${LINKED}]`)) f.removeAttribute(LINKED);
      for (const undo of [...linked.values()]) undo();
      document.removeEventListener("load", onFrameLoad, true);
      host.remove();
      delete window.__pageComments;
    };
    closeBtn.onclick = quickClose.onclick = destroy;
    window.__pageComments = destroy;
    document.documentElement.dataset.pageComments = platform.name;
    document.addEventListener("page-comments:close", destroy);
    placeWidget();
    setCommenting(!platform.startBrowsing);
    const restored = here().length;
    if (restored) toast(`Restored ${restored} comment(s) on this page.`);
    render();
    importShared();
    const [vMajor, vMinor, vPatch] = VERSION.split(".").map(Number);
    if (platform.checkVersion && /^\d+\.\d+\.\d+$/.test(VERSION)) {
      const img = new Image();
      img.referrerPolicy = "no-referrer";
      img.onload = () => {
        if (img.naturalWidth === vMajor * 1e3 + vMinor + 1 && img.naturalHeight === vPatch + 1) return;
        infoLink.classList.add("new");
        infoLink.labelEl.textContent = fromGithub ? "New version: open, then copy the new bookmarklet.txt" : "New version: open, then re-drag the bookmark";
        updateDot.hidden = false;
        layoutBar();
        toast("A new version of page-comments is out: hover the round button, open \u22EF and click the green Help line.");
      };
      img.src = (fromGithub ? "https://raw.githubusercontent.com/adhi14058/page-comments/main/bookmarklet/" : SITE) + "version.svg?t=" + Date.now();
    }
  };

  // content.js
  var api = globalThis.browser ?? chrome;
  var html = document.documentElement;
  var sleep = (ms) => new Promise((ok) => setTimeout(ok, ms));
  var lastShot = 0;
  var grab = async () => {
    await new Promise(requestAnimationFrame);
    const wait = lastShot + 550 - Date.now();
    if (wait > 0) await sleep(wait);
    lastShot = Date.now();
    const reply = await api.runtime.sendMessage({ type: "capture" });
    if (!reply?.dataUrl) throw new Error("click the page-comments icon (or press its shortcut) to take sharp pictures here");
    const bytes = Uint8Array.from(atob(reply.dataUrl.slice(reply.dataUrl.indexOf(",") + 1)), (c) => c.charCodeAt(0));
    const source = await createImageBitmap(new Blob([bytes], { type: "image/png" }));
    return { source, k: source.width / innerWidth };
  };
  var toBase64 = (bytes) => {
    bytes = new Uint8Array(bytes);
    let s = "";
    for (let i = 0; i < bytes.length; i += 32768) s += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return btoa(s);
  };
  var remember = async ({ page, title, count }) => {
    const { index = {} } = await api.storage.local.get("index");
    for (const p of Object.keys(index)) if (p !== page && pageKey(p) === page) delete index[p];
    if (count) index[page] = { title: title || page, count, at: Date.now() };
    else delete index[page];
    await api.storage.local.set({ index });
  };
  var start = (startedBy) => {
    const restoring = globalThis.__pageCommentsRestore;
    delete globalThis.__pageCommentsRestore;
    if (html.dataset.pageComments === "bookmark") document.dispatchEvent(new CustomEvent("page-comments:close"));
    startPageComments({
      name: "extension",
      startedBy,
      // 'bookmark' when the bookmark asked: the tool says so, since it is not the one that was clicked
      shadowMode: "closed",
      // our buttons can take pictures and save files: page scripts must not be able to press them
      checkVersion: false,
      // the store updates the extension
      startBrowsing: !!restoring,
      pictureType: "image/png",
      // captureVisibleTab is lossless; WebP would make thin coloured text pale again
      capture: { ready: () => true, start: async () => {
      }, grab, stop: () => {
      } },
      saveFiles: async (files) => {
        const reply = await api.runtime.sendMessage({ type: "save", files: files.map((f) => ({ name: f.name, data: toBase64(f.bytes) })) });
        if (reply?.error) return `Could not save the pictures (${reply.error}).`;
        return files.length === 1 ? `Saved ${files[0].name} to your Downloads folder.` : `Saved ${files.length} pictures to your Downloads folder.`;
      },
      onComments: (info) => remember(info).catch(() => {
      }),
      // Your name for shared comments, once for every site.
      loadName: async () => (await api.storage.local.get("name")).name || "",
      saveName: (name) => api.storage.local.set({ name }).catch(() => {
      })
    });
  };
  if (!globalThis.__pageCommentsExtension) {
    globalThis.__pageCommentsExtension = true;
    html.dataset.pageCommentsExtension = "1";
    const alive = () => {
      try {
        return !!api.runtime?.id;
      } catch {
        return false;
      }
    };
    const onBookmark = () => {
      if (alive()) return start("bookmark");
      document.removeEventListener("page-comments:start", onBookmark);
      globalThis.__pageComments?.();
      delete html.dataset.pageCommentsExtension;
    };
    document.addEventListener("page-comments:start", onBookmark);
    let armed = false, skipUntil = 0;
    api.runtime.onMessage.addListener((msg) => {
      if (msg.type !== "popup") return;
      if (msg.open) armed = true;
      else setTimeout(() => {
        armed = false;
      }, 300);
    });
    const skip = (e) => {
      if (e.type === "pointerdown" && armed) {
        armed = false;
        skipUntil = Date.now() + 1e3;
      }
      if (Date.now() > skipUntil) return;
      e.stopImmediatePropagation();
      e.preventDefault();
      if (e.type === "click") skipUntil = 0;
    };
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) addEventListener(type, skip, true);
  }
  start();
})();

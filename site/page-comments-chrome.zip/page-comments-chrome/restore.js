(() => {
  // ../core/core.js
  var TRACKING = /^(utm_\w+|fbclid|gclid|gclsrc|dclid|gbraid|wbraid|gad_source|gad_campaignid|msclkid|yclid|ysclid|twclid|ttclid|li_fat_id|epik|sccid|igshid|igsh|srsltid|mc_cid|mc_eid|mkt_tok|_hsenc|_hsmi|__hssc|__hstc|__hsfp|hsctatracking|oly_anon_id|oly_enc_id|vero_id|vero_conv|wickedid|rb_clickid|s_cid|_openstat|_gl|__s|ml_subscriber|ml_subscriber_hash|ss_email_id|bsft_uid|bsft_clkid|guce_referrer|guce_referrer_sig)$/i;
  var pageKey = (href) => {
    const url = String(href).split("#")[0], q = url.indexOf("?");
    if (q < 0) return url;
    const kept = url.slice(q + 1).split("&").filter((p) => !TRACKING.test(p.split("=")[0]));
    return url.slice(0, q) + (kept.length ? "?" + kept.join("&") : "");
  };

  // restore.js
  try {
    const page = pageKey(location.href);
    if (JSON.parse(localStorage.getItem("page-comments:v1") || "[]").some((c) => pageKey(c.page) === page)) (globalThis.browser ?? chrome).runtime.sendMessage({ type: "inject" });
  } catch {
  }
})();
